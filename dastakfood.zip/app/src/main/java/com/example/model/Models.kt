package com.example.model

import kotlinx.serialization.Serializable

@Serializable
data class Product(
    val id: String,
    val name: String,
    val category: String,
    val price: Int,
    val emoji: String = "🍽️",
    val description: String = "",
    val available: Boolean = true,
    val image: String = ""
)

@Serializable
data class Restaurant(
    val id: String,
    val name: String,
    val category: String,
    val kind: String = "restaurant", // restaurant, grocery, shop
    val pickup: Boolean = true,
    val emoji: String = "🍽️",
    val rating: Double = 4.7,
    val reviews: String = "500+",
    val mins: Int = 25,
    val distance: String = "1.2 km",
    val offer: String = "Popular"
)

@Serializable
data class OrderItem(
    val productId: String,
    val name: String,
    val price: Int,
    val quantity: Int,
    val emoji: String = "🍽️"
)

@Serializable
data class OrderLocation(
    val area: String = "",
    val lat: Double? = null,
    val lng: Double? = null
)

@Serializable
data class Order(
    val id: String,
    val orderNumber: String,
    val customerName: String,
    val phone: String,
    val address: String,
    val location: OrderLocation? = null,
    val items: List<OrderItem> = emptyList(),
    val subtotal: Int = 0,
    val deliveryFee: Int = 100,
    val total: Int = 0,
    val payment: String = "Cash on Delivery", // Cash on Delivery, Easypaisa, JazzCash, Bank transfer
    val transactionReference: String = "",
    val paymentStatus: String = "Pay on delivery", // Pay on delivery, Pending manual verification, Verified, Rejected
    val status: String = "New", // New, Confirmed, Preparing, Ready for Pickup, Picked Up, On the Way, Delivered, Cancelled, Unable to Deliver
    val rider: String = "",
    val createdAt: String = "",
    val updatedAt: String = ""
)

@Serializable
data class CustomerUser(
    val id: String,
    val name: String,
    val phone: String,
    val email: String = "",
    val role: String = "customer",
    val createdAt: String = ""
)

@Serializable
data class AppUser(
    val id: String,
    val name: String,
    val phone: String = "",
    val email: String = "",
    val role: String = "customer", // customer, admin, rider
    val createdAt: String = ""
)

@Serializable
data class SupportTicket(
    val id: String,
    val rider: String,
    val orderId: String = "",
    val orderNumber: String = "",
    val issue: String,
    val message: String,
    val status: String = "Open", // Open, In Progress, Resolved
    val createdAt: String = ""
)

@Serializable
data class PaymentConfig(
    val easypaisa: String = "0309-4489584",
    val jazzcash: String = "0300-0854388",
    val bankName: String = "Meezan Bank Ltd",
    val bankTitle: String = "Beerfood Technologies",
    val bankAccount: String = "01020304050607",
    val bankIban: String = "PK36MEZN0001020304050607"
)

enum class AppRole(val appTitle: String, val roleLabel: String, val icon: String) {
    CUSTOMER("Beerfood Customer", "Customer", "🛍️"),
    ADMIN("Beerfood Admin", "Admin", "🏪"),
    RIDER("Beerfood Rider", "Rider", "🛵")
}

