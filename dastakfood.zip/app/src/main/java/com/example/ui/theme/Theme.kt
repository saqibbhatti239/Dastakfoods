package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = ForestGreen,
    onPrimary = SurfaceCard,
    primaryContainer = ForestLight,
    onPrimaryContainer = DeepForest,
    secondary = WarmOrange,
    onSecondary = SurfaceCard,
    secondaryContainer = LimeGreen,
    onSecondaryContainer = InkDark,
    background = CreamBackground,
    onBackground = InkDark,
    surface = SurfaceCard,
    onSurface = InkDark,
    surfaceVariant = CreamBackground,
    onSurfaceVariant = TextMuted,
    outline = LineBorder
)

@Composable
fun BeerfoodTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = ForestGreen.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        shapes = Shapes(),
        content = content
    )
}
