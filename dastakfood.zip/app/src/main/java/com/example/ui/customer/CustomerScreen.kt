package com.example.ui.customer

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.BeerfoodRepository
import com.example.model.CustomerUser
import com.example.model.Order
import com.example.model.PaymentConfig
import com.example.model.Product
import com.example.model.Restaurant
import com.example.ui.components.RealTimeOrderTracker
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatPrice
import com.example.ui.theme.BrightLime
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DeepForest
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestLight
import com.example.ui.theme.InkDark
import com.example.ui.theme.LineBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarmOrange

data class CuisineTile(
    val key: String,
    val emoji: String,
    val label: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerScreen(
    repository: BeerfoodRepository,
    modifier: Modifier = Modifier
) {
    val categories by repository.categories.collectAsState()
    val products by repository.products.collectAsState()
    val orders by repository.orders.collectAsState()
    val currentUser by repository.currentUser.collectAsState()
    val selectedArea by repository.selectedArea.collectAsState()
    val paymentConfig by repository.paymentConfig.collectAsState()
    val context = LocalContext.current

    // Navigation & filters
    var activeMode by remember { mutableStateOf("Delivery") } // Delivery, Pickup, Groceries, Shops
    var selectedCuisine by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var sortOption by remember { mutableStateOf("recommended") } // recommended, rating, fast
    var offerOnly by remember { mutableStateOf(false) }
    var isUrduLanguage by remember { mutableStateOf(false) }

    // Cart: Map<ProductId, Quantity>
    val cart = remember { mutableStateMapOf<String, Int>() }

    // Favorites: Map<RestaurantId, Boolean>
    val favorites = remember { mutableStateMapOf<String, Boolean>() }

    // Modals & Sheets
    var selectedRestaurant by remember { mutableStateOf<Restaurant?>(null) }
    var showCartSheet by remember { mutableStateOf(false) }
    var showAreaDialog by remember { mutableStateOf(false) }
    var showAuthDialog by remember { mutableStateOf(false) }
    var showFavoritesSheet by remember { mutableStateOf(false) }
    var showOrderSuccessDialog by remember { mutableStateOf<Order?>(null) }
    var showMyOrdersDialog by remember { mutableStateOf(false) }
    var showInfoNoticeDialog by remember { mutableStateOf(false) }
    var trackedOrder by remember { mutableStateOf<Order?>(null) }

    val cartTotalCount = cart.values.sum()
    val cartSubtotal = cart.entries.sumOf { (id, qty) ->
        val p = products.find { it.id == id }
        (p?.price ?: 0) * qty
    }

    val cuisineOptions = remember(activeMode, isUrduLanguage) {
        when (activeMode) {
            "Groceries" -> listOf(
                CuisineTile("All", "🥬", if (isUrduLanguage) "سب اشیاء" else "All Picks"),
                CuisineTile("Groceries", "🛒", if (isUrduLanguage) "گروسری" else "Groceries"),
                CuisineTile("Vegetables", "🍅", if (isUrduLanguage) "سبزیاں" else "Vegetables"),
                CuisineTile("Home Items", "🧺", if (isUrduLanguage) "گھریلو سامان" else "Home Items")
            )
            "Shops" -> listOf(
                CuisineTile("All", "🏪", if (isUrduLanguage) "تمام دکانیں" else "All Shops"),
                CuisineTile("Groceries", "🛒", if (isUrduLanguage) "جنرل سٹور" else "General Store"),
                CuisineTile("Vegetables", "🥬", if (isUrduLanguage) "سبزی و پھل" else "Fresh Produce"),
                CuisineTile("Home Items", "🧼", if (isUrduLanguage) "صفائی اشیاء" else "Household")
            )
            else -> listOf(
                CuisineTile("All", "✨", if (isUrduLanguage) "سب" else "All"),
                CuisineTile("Burgers", "🍔", if (isUrduLanguage) "برگر" else "Burgers"),
                CuisineTile("Biryani", "🍛", if (isUrduLanguage) "بریانی" else "Biryani"),
                CuisineTile("Pizza", "🍕", if (isUrduLanguage) "پیزا" else "Pizza"),
                CuisineTile("Pakistani", "🥘", if (isUrduLanguage) "پاکستانی" else "Pakistani"),
                CuisineTile("Desserts", "🍰", if (isUrduLanguage) "میٹھے" else "Desserts"),
                CuisineTile("Drinks", "🧋", if (isUrduLanguage) "مشروبات" else "Drinks"),
                CuisineTile("Groceries", "🛒", if (isUrduLanguage) "گروسری" else "Groceries")
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CreamBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = if (cartTotalCount > 0) 110.dp else 24.dp)
        ) {
            // ── TOP BAR: Logo, Delivering To, Language, Favorites, Account, Cart ──
            item {
                Surface(
                    color = SurfaceCard,
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Logo
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(ForestGreen),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("B", color = BrightLime, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = buildAnnotatedString {
                                            withStyle(SpanStyle(color = ForestGreen, fontWeight = FontWeight.Black, fontSize = 20.sp)) {
                                                append("beer")
                                            }
                                            withStyle(SpanStyle(color = WarmOrange, fontWeight = FontWeight.Black, fontSize = 20.sp)) {
                                                append("food ")
                                            }
                                            withStyle(SpanStyle(color = InkDark, fontWeight = FontWeight.Bold, fontSize = 16.sp)) {
                                                append("Customer")
                                            }
                                        }
                                    )
                                    Text(
                                        "FOOD & GROCERY MARKETPLACE",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextMuted,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }

                            // Right Action Icons: Language, Favorites, Account
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Language Toggle Button
                                TextButton(
                                    onClick = {
                                        isUrduLanguage = !isUrduLanguage
                                        Toast.makeText(
                                            context,
                                            if (isUrduLanguage) "اردو موڈ فعال ہے" else "English is active",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Language, contentDescription = "Language", tint = ForestGreen, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = if (isUrduLanguage) "اردو" else "EN",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ForestGreen
                                    )
                                }

                                // Favorites Icon Button
                                val favCount = favorites.values.count { it }
                                IconButton(
                                    onClick = { showFavoritesSheet = true },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    BadgedBox(
                                        badge = {
                                            if (favCount > 0) {
                                                Badge(containerColor = WarmOrange) {
                                                    Text("$favCount", fontSize = 10.sp, color = Color.White)
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            if (favCount > 0) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                            contentDescription = "Favorites",
                                            tint = if (favCount > 0) Color(0xFFE36A53) else TextMuted,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                // Account / Sign-In Button
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(99.dp))
                                        .background(ForestLight)
                                        .clickable { showAuthDialog = true }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Person, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = currentUser?.name?.take(8) ?: if (isUrduLanguage) "لاگ ان" else "Sign in",
                                            color = ForestGreen,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Location Bar Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(CreamBackground)
                                .clickable { showAreaDialog = true }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = ForestGreen, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = if (isUrduLanguage) "ڈلیوری کا پتہ" else "DELIVERING TO",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextMuted,
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = "$selectedArea ▾",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = InkDark,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            TextButton(
                                onClick = { showMyOrdersDialog = true },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    if (isUrduLanguage) "میرے آرڈرز" else "Orders (${orders.size})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ForestGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // ── Service Mode Selector: Delivery, Pickup, Groceries, Shops ──
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                Triple("Delivery", if (isUrduLanguage) "ڈلیوری" else "Delivery", "⌁"),
                                Triple("Pickup", if (isUrduLanguage) "پک اپ" else "Pickup", "♧"),
                                Triple("Groceries", if (isUrduLanguage) "گروسری" else "Groceries", "▤"),
                                Triple("Shops", if (isUrduLanguage) "دکانیں" else "Shops", "⌂")
                            ).forEach { (mode, label, symbol) ->
                                val isSelected = activeMode == mode
                                val animatedBg by animateColorAsState(if (isSelected) ForestGreen else CreamBackground, label = "bg")
                                val animatedText by animateColorAsState(if (isSelected) Color.White else InkDark, label = "text")

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(animatedBg)
                                        .clickable {
                                            activeMode = mode
                                            selectedCuisine = "All"
                                            Toast.makeText(context, "$mode selected", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(vertical = 9.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(symbol, fontSize = 11.sp, color = animatedText)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = label,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = animatedText
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // ── Large Search Field ──
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    if (isUrduLanguage) "ریستوران، کھانا یا گروسری تلاش کریں..."
                                    else if (activeMode == "Groceries") "Search fresh dairy, produce & essentials..."
                                    else "Search restaurants, dishes & groceries...",
                                    fontSize = 13.sp,
                                    color = TextMuted
                                )
                            },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ForestGreen) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextMuted)
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_field")
                        )
                    }
                }
            }

            // ── Hero Promotional Banner ──
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Box(modifier = Modifier.fillMaxWidth().height(160.dp)) {
                        Image(
                            painter = painterResource(
                                id = if (activeMode == "Groceries" || activeMode == "Shops") R.drawable.grocery_banner else R.drawable.hero_banner
                            ),
                            contentDescription = "Beerfood Marketplace",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            DeepForest.copy(alpha = 0.90f),
                                            DeepForest.copy(alpha = 0.65f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .padding(18.dp)
                                .align(Alignment.CenterStart)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(BrightLime)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = if (activeMode == "Groceries") "FRESH PRODUCE & DAIRY" else "SPECIAL PROMO CODE: BEERFOOD",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = DeepForest
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (activeMode == "Groceries") "Fresh Market To Your Door" else "Good food, close by.",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Text(
                                text = if (activeMode == "Groceries") "Organic veggies, dairy & daily staples delivered fast."
                                else "Neighborhood favorites and fresh groceries at your doorstep.",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.92f)
                            )
                        }
                    }
                }
            }

            // ── Real-Time Order Tracking Progress Bar ──
            val liveOrder = trackedOrder ?: orders.firstOrNull {
                !listOf("Delivered", "Cancelled", "Unable to Deliver").contains(it.status)
            }
            if (liveOrder != null) {
                item {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        RealTimeOrderTracker(
                            order = liveOrder,
                            onDismiss = {
                                trackedOrder = null
                            }
                        )
                    }
                }
            }

            // ── Cravings & Category Tiles ──
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isUrduLanguage) "اپنی پسند منتخب کریں" else "Explore by craving",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = InkDark
                        )
                        TextButton(onClick = { selectedCuisine = "All" }) {
                            Text(if (isUrduLanguage) "سب دیکھیں" else "See all →", color = ForestGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(cuisineOptions) { tile ->
                            val isSelected = selectedCuisine == tile.key
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) ForestGreen else SurfaceCard,
                                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { selectedCuisine = tile.key }
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                ) {
                                    Text(tile.emoji, fontSize = 26.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = tile.label,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else InkDark
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ── Promotional Deals Cards ──
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text(
                        text = if (isUrduLanguage) "خاص پیشکشیں" else "Deals picked for you",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            DealCard(
                                title = "Welcome treat",
                                subtitle = "Save on your first order",
                                code = "Code BEERFOOD · Min Rs 500",
                                emoji = "🍔",
                                bgGradient = listOf(ForestGreen, DeepForest),
                                textColor = Color.White
                            )
                        }
                        item {
                            DealCard(
                                title = "Lunch favorite",
                                subtitle = "Handi & Biryani combos",
                                code = "Meals from Rs. 299",
                                emoji = "🍛",
                                bgGradient = listOf(Color(0xFFE4EFAD), Color(0xFFC7DC8A)),
                                textColor = InkDark
                            )
                        }
                        item {
                            DealCard(
                                title = "Daily essentials",
                                subtitle = "Fresh dairy & farm eggs",
                                code = "Direct from local market",
                                emoji = "🥛",
                                bgGradient = listOf(Color(0xFFFFEAD2), Color(0xFFF9D1A8)),
                                textColor = InkDark
                            )
                        }
                    }
                }
            }

            // ── Sort & Filter Controls ──
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Offers only toggle
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(if (offerOnly) ForestLight else SurfaceCard)
                            .border(1.dp, if (offerOnly) ForestGreen else LineBorder, RoundedCornerShape(99.dp))
                            .clickable { offerOnly = !offerOnly }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (offerOnly) "✓ Offers only" else "🏷️ Offers",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (offerOnly) ForestGreen else InkDark
                        )
                    }

                    // Sort options
                    listOf(
                        "recommended" to (if (isUrduLanguage) "تجویز کردہ" else "Recommended"),
                        "rating" to (if (isUrduLanguage) "اعلیٰ درجہ بندی" else "Top Rated"),
                        "fast" to (if (isUrduLanguage) "تیز رفتار" else "Fastest")
                    ).forEach { (key, label) ->
                        val isSelected = sortOption == key
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(if (isSelected) ForestGreen else SurfaceCard)
                                .border(1.dp, if (isSelected) ForestGreen else LineBorder, RoundedCornerShape(99.dp))
                                .clickable { sortOption = key }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else InkDark
                            )
                        }
                    }
                }
            }

            // ── Section Title: Popular Places Around You ──
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (selectedCuisine == "All") (if (isUrduLanguage) "آپ کے قریب مقبول جگہیں" else "Popular around you")
                            else "$selectedCuisine near you",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = InkDark
                        )
                        Text(
                            text = when (activeMode) {
                                "Groceries" -> "Fresh grocery shops delivering in $selectedArea"
                                "Shops" -> "Local neighborhood general & household shops"
                                "Pickup" -> "Orders ready for self-pickup"
                                else -> "Verified restaurants and kitchens delivering to $selectedArea"
                            },
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }

                    // Offline simulation info badge
                    IconButton(onClick = { showInfoNoticeDialog = true }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Info, contentDescription = "Setup notice", tint = TextMuted)
                    }
                }
            }

            // ── Restaurant & Store Cards ──
            val filteredRestaurants = repository.restaurants.filter { r ->
                val modeMatch = when (activeMode) {
                    "Delivery" -> r.kind == "restaurant"
                    "Pickup" -> r.pickup
                    "Groceries" -> r.kind == "grocery"
                    "Shops" -> r.kind == "shop" || r.kind == "grocery"
                    else -> true
                }
                val cuisineMatch = selectedCuisine == "All" ||
                        r.category.equals(selectedCuisine, ignoreCase = true) ||
                        (selectedCuisine == "Fast Food" && (r.category == "Burgers" || r.category == "Pizza"))
                val searchMatch = searchQuery.isBlank() ||
                        r.name.contains(searchQuery, ignoreCase = true) ||
                        r.category.contains(searchQuery, ignoreCase = true)
                val offerMatch = !offerOnly || r.offer.isNotEmpty()

                modeMatch && cuisineMatch && searchMatch && offerMatch
            }.sortedWith { a, b ->
                when (sortOption) {
                    "rating" -> b.rating.compareTo(a.rating)
                    "fast" -> a.mins.compareTo(b.mins)
                    else -> 0
                }
            }

            if (filteredRestaurants.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                            .background(SurfaceCard, RoundedCornerShape(16.dp))
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🍽️", fontSize = 42.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isUrduLanguage) "کوئی ریستوران نہیں ملا" else "No places found matching your filters",
                                fontWeight = FontWeight.Bold,
                                color = InkDark
                            )
                            Text(
                                text = if (isUrduLanguage) "براہ کرم تلاش تبدیل کریں" else "Try clearing your search or picking another category.",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        }
                    }
                }
            } else {
                items(filteredRestaurants) { restaurant ->
                    RestaurantCard(
                        restaurant = restaurant,
                        isFavorite = favorites[restaurant.id] ?: false,
                        onFavoriteToggle = {
                            val newVal = !(favorites[restaurant.id] ?: false)
                            favorites[restaurant.id] = newVal
                            Toast.makeText(
                                context,
                                if (newVal) "Saved to favorites ❤️" else "Removed from favorites",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        onClick = { selectedRestaurant = restaurant }
                    )
                }
            }
        }

        // ── Floating Cart Bar ──
        if (cartTotalCount > 0) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                color = InkDark,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(BrightLime)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "$cartTotalCount items",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = DeepForest
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Your Basket", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                            Text(
                                text = formatPrice(cartSubtotal),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Button(
                        onClick = { showCartSheet = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("View Cart", fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }

    // ── Restaurant / Store Menu Bottom Sheet ──
    selectedRestaurant?.let { restaurant ->
        val menuItems = products.filter { p ->
            if (restaurant.id == "basket") p.category == "Groceries" && p.available
            else if (restaurant.id == "street") p.category == "Burgers" && p.available
            else p.category == restaurant.category && p.available
        }

        ModalBottomSheet(
            onDismissRequest = { selectedRestaurant = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = SurfaceCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(restaurant.emoji, fontSize = 36.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(restaurant.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = InkDark)
                            Text(
                                text = "★ ${restaurant.rating} (${restaurant.reviews}) · ${restaurant.category} · ${restaurant.mins} min",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        }
                    }
                    IconButton(onClick = { selectedRestaurant = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                if (restaurant.offer.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(ForestLight)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("🏷️ Offer: ${restaurant.offer}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ForestGreen)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = LineBorder)

                Text(if (isUrduLanguage) "دستیاب مینو" else "Available Items", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkDark)
                Spacer(modifier = Modifier.height(8.dp))

                if (menuItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Menu items being refreshed. Check back shortly.", color = TextMuted)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(350.dp)
                    ) {
                        items(menuItems) { product ->
                            val qty = cart[product.id] ?: 0
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(product.emoji, fontSize = 28.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(product.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = InkDark)
                                        if (product.description.isNotEmpty()) {
                                            Text(product.description, fontSize = 11.sp, color = TextMuted, maxLines = 2)
                                        }
                                        Text(formatPrice(product.price), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ForestGreen)
                                    }
                                }

                                if (qty == 0) {
                                    Button(
                                        onClick = {
                                            cart[product.id] = 1
                                            Toast.makeText(context, "${product.name} added to cart", Toast.LENGTH_SHORT).show()
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text("Add +", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .border(1.dp, LineBorder, RoundedCornerShape(8.dp))
                                            .padding(2.dp)
                                    ) {
                                        IconButton(
                                            onClick = {
                                                if (qty > 1) cart[product.id] = qty - 1
                                                else cart.remove(product.id)
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                                        }
                                        Text(
                                            text = "$qty",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp)
                                        )
                                        IconButton(
                                            onClick = { cart[product.id] = qty + 1 },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = LineBorder.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }

    // ── Cart & Checkout Bottom Sheet ──
    if (showCartSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCartSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = SurfaceCard
        ) {
            CheckoutSheetContent(
                cart = cart,
                products = products,
                currentUser = currentUser,
                selectedArea = selectedArea,
                paymentConfig = paymentConfig,
                onDismiss = { showCartSheet = false },
                onOrderPlaced = { order: Order ->
                    cart.clear()
                    showCartSheet = false
                    showOrderSuccessDialog = order
                },
                repository = repository
            )
        }
    }

    // ── Favorites Bottom Sheet ──
    if (showFavoritesSheet) {
        val favRestaurants = repository.restaurants.filter { favorites[it.id] == true }
        ModalBottomSheet(
            onDismissRequest = { showFavoritesSheet = false },
            containerColor = SurfaceCard
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Your Favorite Places (${favRestaurants.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    IconButton(onClick = { showFavoritesSheet = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))

                if (favRestaurants.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("❤️", fontSize = 40.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No favorites yet", fontWeight = FontWeight.Bold, color = InkDark)
                            Text("Tap the heart icon on any restaurant to save it here.", fontSize = 12.sp, color = TextMuted)
                        }
                    }
                } else {
                    LazyColumn(modifier = Modifier.height(300.dp)) {
                        items(favRestaurants) { rest ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showFavoritesSheet = false
                                        selectedRestaurant = rest
                                    }
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(rest.emoji, fontSize = 28.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(rest.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("★ ${rest.rating} · ${rest.category} · ${rest.mins} min", fontSize = 11.sp, color = TextMuted)
                                    }
                                }
                                Button(
                                    onClick = {
                                        showFavoritesSheet = false
                                        selectedRestaurant = rest
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("Open Menu", fontSize = 11.sp)
                                }
                            }
                            HorizontalDivider(color = LineBorder.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }

    // ── Delivery Location Dialog ──
    if (showAreaDialog) {
        var manualAreaInput by remember { mutableStateOf("") }
        val commonLahoreAreas = listOf(
            "Mohra Sharif, Lahore",
            "Gulberg III, Lahore",
            "DHA Phase 3, Lahore",
            "Model Town, Lahore",
            "Johar Town, Lahore",
            "Faisal Town, Lahore",
            "Bahria Town, Lahore"
        )

        AlertDialog(
            onDismissRequest = { showAreaDialog = false },
            title = { Text("Choose your delivery area", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Beerfood delivers to neighborhoods and housing sectors across Lahore.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Use current location action
                    OutlinedButton(
                        onClick = {
                            repository.setArea("Current GPS Location (Lahore)")
                            Toast.makeText(context, "Location pinned to current GPS area", Toast.LENGTH_SHORT).show()
                            showAreaDialog = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.MyLocation, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Use My Current Location", color = ForestGreen, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = manualAreaInput,
                        onValueChange = { manualAreaInput = it },
                        placeholder = { Text("Or enter neighborhood / area") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Quick Picks:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    Spacer(modifier = Modifier.height(6.dp))
                    commonLahoreAreas.forEach { area ->
                        Text(
                            text = "📍 $area",
                            fontSize = 13.sp,
                            color = ForestGreen,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    repository.setArea(area)
                                    showAreaDialog = false
                                }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (manualAreaInput.isNotBlank()) {
                            repository.setArea(manualAreaInput.trim())
                        }
                        showAreaDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Set Area")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAreaDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ── Phone OTP Auth Dialog ──
    if (showAuthDialog) {
        AuthDialog(
            currentUser = currentUser,
            onDismiss = { showAuthDialog = false },
            repository = repository
        )
    }

    // ── Order Success Confirmation Dialog ──
    showOrderSuccessDialog?.let { order ->
        AlertDialog(
            onDismissRequest = { showOrderSuccessDialog = null },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(44.dp)) },
            title = { Text("Order Placed Successfully!", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Your order #${order.orderNumber} has been sent to the store.", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Status: ${order.status} (${order.paymentStatus})", fontSize = 12.sp, color = ForestGreen)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Total: ${formatPrice(order.total)} via ${order.payment}", fontSize = 13.sp)
                    if (order.transactionReference.isNotEmpty()) {
                        Text("Ref ID: ${order.transactionReference}", fontSize = 12.sp, color = TextMuted)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Delivery address: ${order.address}", fontSize = 12.sp, color = TextMuted)
                }
            },
            confirmButton = {
                Button(
                    onClick = { showOrderSuccessDialog = null },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Got it")
                }
            }
        )
    }

    // ── My Orders Dialog ──
    if (showMyOrdersDialog) {
        AlertDialog(
            onDismissRequest = { showMyOrdersDialog = false },
            title = { Text("My Orders (${orders.size})", fontWeight = FontWeight.Bold) },
            text = {
                if (orders.isEmpty()) {
                    Text("No past orders found.", color = TextMuted)
                } else {
                    LazyColumn(modifier = Modifier.height(320.dp)) {
                        items(orders) { order ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(order.orderNumber, fontWeight = FontWeight.Bold, color = ForestGreen)
                                        StatusBadge(status = order.status)
                                    }
                                    Text(
                                        text = order.items.joinToString { "${it.emoji} ${it.name} x${it.quantity}" },
                                        fontSize = 12.sp,
                                        color = InkDark
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(formatPrice(order.total), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        OutlinedButton(
                                            onClick = {
                                                trackedOrder = order
                                                showMyOrdersDialog = false
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("Track Live ↗", fontSize = 11.sp, color = ForestGreen, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    if (order.rider.isNotEmpty()) {
                                        Text("Assigned rider: ${order.rider}", fontSize = 11.sp, color = ForestGreen, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showMyOrdersDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Close")
                }
            }
        )
    }

    // ── Provider Setup Notice Dialog ──
    if (showInfoNoticeDialog) {
        AlertDialog(
            onDismissRequest = { showInfoNoticeDialog = false },
            icon = { Icon(Icons.Default.Info, contentDescription = null, tint = ForestGreen) },
            title = { Text("Beerfood Provider Configuration", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "• SMS OTP: Configured in simulated free local testing mode. (Number: +1 202-555-0147, code: 583104; live SMS requires Twilio Verify credentials in environment variables).",
                        fontSize = 12.sp,
                        color = InkDark
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "• Google Maps: Geolocation coordinates pinned locally; live interactive Google Maps embeds require Google Cloud Maps API key.",
                        fontSize = 12.sp,
                        color = InkDark
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "• Payment Gateway: Cash on Delivery is active; Easypaisa, JazzCash, and Bank transfers use simulated manual transaction verification.",
                        fontSize = 12.sp,
                        color = InkDark
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showInfoNoticeDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Understood")
                }
            }
        )
    }
}

@Composable
fun DealCard(
    title: String,
    subtitle: String,
    code: String,
    emoji: String,
    bgGradient: List<Color>,
    textColor: Color
) {
    Box(
        modifier = Modifier
            .width(220.dp)
            .height(115.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(bgGradient))
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(title.uppercase(), fontSize = 9.sp, fontWeight = FontWeight.Black, color = textColor.copy(alpha = 0.75f))
                Text(subtitle, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = textColor, maxLines = 1)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(code, fontSize = 10.sp, fontWeight = FontWeight.Medium, color = textColor.copy(alpha = 0.85f))
                Text(emoji, fontSize = 32.sp)
            }
        }
    }
}

@Composable
fun RestaurantCard(
    restaurant: Restaurant,
    isFavorite: Boolean,
    onFavoriteToggle: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder)
    ) {
        Column {
            // Header cover banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(95.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFFE0F0E5), Color(0xFFF3E7C1))
                        )
                    )
            ) {
                Text(
                    text = restaurant.emoji,
                    fontSize = 54.sp,
                    modifier = Modifier.align(Alignment.Center)
                )

                if (restaurant.offer.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(SurfaceCard)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(restaurant.offer, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = InkDark)
                    }
                }

                IconButton(
                    onClick = onFavoriteToggle,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard.copy(alpha = 0.85f))
                ) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) Color(0xFFE36A53) else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Info body
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(restaurant.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFDC902E), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${restaurant.rating}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = InkDark
                        )
                        Text(
                            text = " (${restaurant.reviews})",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                Text(
                    text = "${restaurant.category} · Neighborhood favorite",
                    fontSize = 11.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "⏱ ${restaurant.mins}–${restaurant.mins + 10} min",
                        fontSize = 11.sp,
                        color = ForestGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "  ·  ${restaurant.distance}",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutSheetContent(
    cart: Map<String, Int>,
    products: List<Product>,
    currentUser: CustomerUser?,
    selectedArea: String,
    paymentConfig: PaymentConfig,
    onDismiss: () -> Unit,
    onOrderPlaced: (Order) -> Unit,
    repository: BeerfoodRepository
) {
    var customerName by remember { mutableStateOf(currentUser?.name ?: "") }
    var customerPhone by remember { mutableStateOf(currentUser?.phone ?: "") }
    var customerAddress by remember { mutableStateOf("Street 24, House 67, $selectedArea") }
    var selectedPayment by remember { mutableStateOf("Cash on Delivery") }
    var transactionReference by remember { mutableStateOf("") }
    var promoCodeInput by remember { mutableStateOf("") }
    var discountApplied by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    val cartItems = cart.mapNotNull { (id, qty) ->
        val p = products.find { it.id == id }
        if (p != null) p to qty else null
    }

    val subtotal = cartItems.sumOf { (p, qty) -> p.price * qty }
    val baseDeliveryFee = if (cartItems.isNotEmpty()) 100 else 0
    val discountAmount = if (discountApplied) 100 else 0
    val total = (subtotal + baseDeliveryFee - discountAmount).coerceAtLeast(0)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Your Beerfood Basket", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = InkDark)
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Close")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(115.dp)
        ) {
            items(cartItems) { (product, qty) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${product.emoji} ${product.name} × $qty",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = formatPrice(product.price * qty),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        HorizontalDivider(color = LineBorder, modifier = Modifier.padding(vertical = 6.dp))

        // Promo Code Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = promoCodeInput,
                onValueChange = { promoCodeInput = it },
                placeholder = { Text("Promo Code (e.g. BEERFOOD)") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Button(
                onClick = {
                    if (promoCodeInput.trim().equals("BEERFOOD", ignoreCase = true)) {
                        discountApplied = true
                        errorMessage = "Promo applied! Rs. 100 delivery fee waived."
                    } else {
                        errorMessage = "Invalid code. Use code BEERFOOD."
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ForestLight),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Apply", color = ForestGreen, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Delivery Form
        Text("Delivery Details", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = InkDark)
        Spacer(modifier = Modifier.height(4.dp))

        OutlinedTextField(
            value = customerName,
            onValueChange = { customerName = it },
            label = { Text("Your Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(4.dp))

        OutlinedTextField(
            value = customerPhone,
            onValueChange = { customerPhone = it },
            label = { Text("Phone Number (e.g. 03xx xxxxxxx)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(4.dp))

        OutlinedTextField(
            value = customerAddress,
            onValueChange = { customerAddress = it },
            label = { Text("Delivery Address (House, street, area)") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 2
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Payment Method Dropdown
        Text("Payment Method", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = InkDark)
        Spacer(modifier = Modifier.height(3.dp))

        var paymentExpanded by remember { mutableStateOf(false) }
        val paymentOptions = listOf("Cash on Delivery", "Easypaisa", "JazzCash", "Bank transfer")

        ExposedDropdownMenuBox(
            expanded = paymentExpanded,
            onExpandedChange = { paymentExpanded = !paymentExpanded }
        ) {
            OutlinedTextField(
                value = selectedPayment,
                onValueChange = {},
                readOnly = true,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = paymentExpanded) },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = paymentExpanded,
                onDismissRequest = { paymentExpanded = false }
            ) {
                paymentOptions.forEach { method ->
                    DropdownMenuItem(
                        text = { Text(method) },
                        onClick = {
                            selectedPayment = method
                            paymentExpanded = false
                        }
                    )
                }
            }
        }

        // Show payment instructions based on selection
        when (selectedPayment) {
            "Easypaisa" -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .background(ForestLight, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "Send total to Easypaisa: ${paymentConfig.easypaisa}. Then enter the transaction reference below.",
                        fontSize = 11.sp,
                        color = ForestGreen
                    )
                }
            }
            "JazzCash" -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .background(ForestLight, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "Send total to JazzCash: ${paymentConfig.jazzcash}. Then enter the transaction reference below.",
                        fontSize = 11.sp,
                        color = ForestGreen
                    )
                }
            }
            "Bank transfer" -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .background(ForestLight, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "${paymentConfig.bankName} | Title: ${paymentConfig.bankTitle} | A/C: ${paymentConfig.bankAccount}\nIBAN: ${paymentConfig.bankIban}",
                        fontSize = 11.sp,
                        color = ForestGreen
                    )
                }
            }
        }

        if (selectedPayment != "Cash on Delivery") {
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = transactionReference,
                onValueChange = { transactionReference = it },
                label = { Text("Transaction Reference ID *") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        if (errorMessage.isNotEmpty()) {
            Text(
                text = errorMessage,
                color = if (errorMessage.startsWith("Promo")) ForestGreen else MaterialTheme.colorScheme.error,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Price totals
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Subtotal", fontSize = 12.sp, color = TextMuted)
            Text(formatPrice(subtotal), fontSize = 12.sp)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Delivery Fee", fontSize = 12.sp, color = TextMuted)
            Text(if (discountApplied) "FREE (Promo)" else formatPrice(baseDeliveryFee), fontSize = 12.sp, color = if (discountApplied) ForestGreen else InkDark)
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Total", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkDark)
            Text(formatPrice(total), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ForestGreen)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                if (selectedPayment != "Cash on Delivery" && transactionReference.isBlank()) {
                    errorMessage = "Please enter your payment transaction reference."
                    return@Button
                }
                val result = repository.placeOrder(
                    customerName = customerName,
                    phone = customerPhone,
                    address = customerAddress,
                    cartItems = cart,
                    paymentMethod = selectedPayment,
                    transactionReference = transactionReference,
                    area = selectedArea
                )
                result.fold(
                    onSuccess = { order -> onOrderPlaced(order) },
                    onFailure = { err -> errorMessage = err.message ?: "Failed to place order" }
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("Place Order (${formatPrice(total)})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

@Composable
fun AuthDialog(
    currentUser: CustomerUser?,
    onDismiss: () -> Unit,
    repository: BeerfoodRepository
) {
    var phoneInput by remember { mutableStateOf(currentUser?.phone ?: "+1 202-555-0147") }
    var codeInput by remember { mutableStateOf("583104") }
    var nameInput by remember { mutableStateOf(currentUser?.name ?: "Saqib Bhatti") }
    var step by remember { mutableIntStateOf(if (currentUser != null) 3 else 1) } // 1: Enter Phone, 2: Enter Code, 3: Signed In View
    var message by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (step == 3) "Your Beerfood Account" else "Sign in to Beerfood",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                if (step == 3 && currentUser != null) {
                    Text("Logged in as:", fontSize = 12.sp, color = TextMuted)
                    Text(currentUser.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ForestGreen)
                    Text("Phone: ${currentUser.phone}", fontSize = 13.sp, color = InkDark)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            repository.logout()
                            step = 1
                            message = "Signed out."
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFF0EE)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Sign Out", color = Color(0xFFC3443D), fontWeight = FontWeight.Bold)
                    }
                } else if (step == 1) {
                    Text(
                        text = "Phone OTP sign-in for Beerfood order updates.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ForestLight, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            "FREE TEST MODE: Use +1 202-555-0147 and OTP 583104 (or your number with any 6-digit code). Live SMS requires Twilio Verify credentials.",
                            fontSize = 11.sp,
                            color = ForestGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Your Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (step == 2) {
                    Text("Enter the 6-digit code sent to $phoneInput", fontSize = 13.sp, color = InkDark)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it },
                        label = { Text("6-Digit Code (e.g. 583104)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (message.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(message, fontSize = 12.sp, color = ForestGreen, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            if (step == 1) {
                Button(
                    onClick = {
                        if (phoneInput.isBlank()) {
                            message = "Enter your phone number."
                        } else {
                            step = 2
                            message = "SMS code simulated. Code: 583104"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Send Code")
                }
            } else if (step == 2) {
                Button(
                    onClick = {
                        val res = repository.verifyOtp(phoneInput, codeInput, nameInput)
                        res.fold(
                            onSuccess = {
                                step = 3
                                message = "Verified! Welcome, ${it.name}."
                                onDismiss()
                            },
                            onFailure = {
                                message = it.message ?: "Verification failed."
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Verify & Continue")
                }
            } else {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Done")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
