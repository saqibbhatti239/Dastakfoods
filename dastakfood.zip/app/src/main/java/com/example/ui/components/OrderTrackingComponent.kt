package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.OutdoorGrill
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DeepForest
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestLight
import com.example.ui.theme.InkDark
import com.example.ui.theme.LineBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarmOrange

enum class TrackingStep(
    val title: String,
    val subtitle: String,
    val progress: Float
) {
    PLACED("Order Placed", "Store received your request", 0.15f),
    CONFIRMED("Confirmed", "Store confirmed and assigned rider", 0.35f),
    PREPARING("Preparing", "Kitchen is packing your fresh items", 0.60f),
    OUT_FOR_DELIVERY("Out for Delivery", "Rider is heading to your doorstep", 0.85f),
    DELIVERED("Delivered", "Delivered hot & fresh. Enjoy!", 1.0f),
    CANCELLED("Cancelled", "Order was cancelled", 0.0f)
}

fun orderToTrackingStep(status: String): TrackingStep {
    return when (status) {
        "New" -> TrackingStep.PLACED
        "Confirmed" -> TrackingStep.CONFIRMED
        "Preparing", "Ready for Pickup" -> TrackingStep.PREPARING
        "Picked Up", "On the Way" -> TrackingStep.OUT_FOR_DELIVERY
        "Delivered" -> TrackingStep.DELIVERED
        "Cancelled", "Unable to Deliver" -> TrackingStep.CANCELLED
        else -> TrackingStep.PLACED
    }
}

@Composable
fun RealTimeOrderTracker(
    order: Order,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentStep = orderToTrackingStep(order.status)
    val isCancelled = currentStep == TrackingStep.CANCELLED

    // Pulse animation for active step
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isCancelled) Color(0xFFFFF0EE) else ForestLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCancelled) Icons.Default.Close else Icons.Default.DeliveryDining,
                            contentDescription = null,
                            tint = if (isCancelled) DangerRed else ForestGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Live Order Tracking",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = InkDark
                        )
                        Text(
                            text = "Order #${order.orderNumber}",
                            fontSize = 12.sp,
                            color = ForestGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress Bar
            if (!isCancelled) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = currentStep.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreen
                        )
                        Text(
                            text = when (currentStep) {
                                TrackingStep.PLACED -> "Est. 25-30 min"
                                TrackingStep.CONFIRMED -> "Est. 20-25 min"
                                TrackingStep.PREPARING -> "Est. 15-20 min"
                                TrackingStep.OUT_FOR_DELIVERY -> "Arriving in ~8-12 min"
                                TrackingStep.DELIVERED -> "Completed"
                                else -> ""
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = WarmOrange
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { currentStep.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(99.dp)),
                        color = ForestGreen,
                        trackColor = ForestLight
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Step Circles Representation
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StepIndicator(
                            stepNumber = 1,
                            label = "Placed",
                            isActive = currentStep.ordinal >= TrackingStep.PLACED.ordinal,
                            isCurrent = currentStep == TrackingStep.PLACED,
                            pulseScale = pulseScale
                        )
                        StepDivider(isActive = currentStep.ordinal >= TrackingStep.CONFIRMED.ordinal)
                        StepIndicator(
                            stepNumber = 2,
                            label = "Confirmed",
                            isActive = currentStep.ordinal >= TrackingStep.CONFIRMED.ordinal,
                            isCurrent = currentStep == TrackingStep.CONFIRMED,
                            pulseScale = pulseScale
                        )
                        StepDivider(isActive = currentStep.ordinal >= TrackingStep.PREPARING.ordinal)
                        StepIndicator(
                            stepNumber = 3,
                            label = "Kitchen",
                            isActive = currentStep.ordinal >= TrackingStep.PREPARING.ordinal,
                            isCurrent = currentStep == TrackingStep.PREPARING,
                            pulseScale = pulseScale
                        )
                        StepDivider(isActive = currentStep.ordinal >= TrackingStep.OUT_FOR_DELIVERY.ordinal)
                        StepIndicator(
                            stepNumber = 4,
                            label = "Rider",
                            isActive = currentStep.ordinal >= TrackingStep.OUT_FOR_DELIVERY.ordinal,
                            isCurrent = currentStep == TrackingStep.OUT_FOR_DELIVERY,
                            pulseScale = pulseScale
                        )
                        StepDivider(isActive = currentStep.ordinal >= TrackingStep.DELIVERED.ordinal)
                        StepIndicator(
                            stepNumber = 5,
                            label = "Arrived",
                            isActive = currentStep == TrackingStep.DELIVERED,
                            isCurrent = currentStep == TrackingStep.DELIVERED,
                            pulseScale = pulseScale
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFFFF0EE), RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "This delivery was cancelled. Contact store admin if you need support.",
                        color = DangerRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = LineBorder)

            // Live Rider Status & Delivery Location Card
            if (order.rider.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CreamBackground, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(ForestGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🛵", fontSize = 16.sp)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Rider: ${order.rider}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = InkDark
                                )
                                Text(
                                    text = if (currentStep == TrackingStep.OUT_FOR_DELIVERY)
                                        "Approaching: ${order.location?.area ?: "Near neighborhood"}"
                                    else
                                        "Assigned for delivery",
                                    fontSize = 11.sp,
                                    color = ForestGreen,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Call rider button
                        OutlinedButton(
                            onClick = {
                                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:03001234567"))
                                context.startActivity(dialIntent)
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Call rider", tint = ForestGreen, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call", fontSize = 11.sp, color = ForestGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }

            // Order Destination & Items Summary
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Delivery to: ${order.address}",
                    fontSize = 12.sp,
                    color = InkDark,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "${order.items.size} items · Total: ${formatPrice(order.total)} (${order.payment})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted
            )
        }
    }
}

@Composable
private fun StepIndicator(
    stepNumber: Int,
    label: String,
    isActive: Boolean,
    isCurrent: Boolean,
    pulseScale: Float
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .scale(if (isCurrent) pulseScale else 1f)
                .clip(CircleShape)
                .background(if (isActive) ForestGreen else LineBorder)
                .border(2.dp, if (isCurrent) WarmOrange else Color.Transparent, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (isActive) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
            } else {
                Text(
                    text = "$stepNumber",
                    fontSize = 10.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Medium,
            color = if (isActive) ForestGreen else TextMuted
        )
    }
}

@Composable
private fun StepDivider(isActive: Boolean) {
    Box(
        modifier = Modifier
            .width(20.dp)
            .height(3.dp)
            .background(if (isActive) ForestGreen else LineBorder)
    )
}
