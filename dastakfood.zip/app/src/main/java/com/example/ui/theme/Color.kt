package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ForestGreen = Color(0xFF18745F)
val DeepForest = Color(0xFF105344)
val ForestLight = Color(0xFFE5F2E8)
val LimeGreen = Color(0xFFE4F19A)
val BrightLime = Color(0xFFD9F27C)
val WarmOrange = Color(0xFFF2A451)
val CreamBackground = Color(0xFFF7F6EF)
val SurfaceCard = Color(0xFFFFFFFF)
val LineBorder = Color(0xFFE8E8DC)
val InkDark = Color(0xFF1C302B)
val TextMuted = Color(0xFF707B75)
val DangerRed = Color(0xFFC3443D)
val DangerRedLight = Color(0xFFFFF0EE)
val WarningYellow = Color(0xFFFFF3D5)
val WarningYellowText = Color(0xFF88620C)
val InfoBlue = Color(0xFFE8F2FF)
val InfoBlueText = Color(0xFF2B64A0)
val SuccessGreen = Color(0xFFE6F5E9)
val SuccessGreenText = Color(0xFF267343)
