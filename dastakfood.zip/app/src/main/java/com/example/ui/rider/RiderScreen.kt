package com.example.ui.rider

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Motorcycle
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BeerfoodRepository
import com.example.model.Order
import com.example.ui.components.PaymentStatusBadge
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatPrice
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerRedLight
import com.example.ui.theme.DeepForest
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestLight
import com.example.ui.theme.InkDark
import com.example.ui.theme.LineBorder
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import java.net.URLEncoder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiderScreen(
    repository: BeerfoodRepository,
    modifier: Modifier = Modifier
) {
    val orders by repository.orders.collectAsState()
    val riderStatuses by repository.riderStatuses.collectAsState()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val riderNames = listOf("Rider 1", "Ali Khan", "Usman", "Hamza")
    var selectedRider by remember { mutableStateOf("Rider 1") }
    var deliveryFilter by remember { mutableStateOf("active") } // available, active, completed
    var showSupportDialogForOrder by remember { mutableStateOf<Order?>(null) }
    var orderToUpdateLocation by remember { mutableStateOf<Order?>(null) }

    val isOnline = riderStatuses[selectedRider] ?: true

    // Filter categories
    val availableOrders = orders.filter { it.rider.isBlank() && !listOf("Delivered", "Cancelled", "Unable to Deliver").contains(it.status) }
    val myOrders = orders.filter { it.rider.equals(selectedRider, ignoreCase = true) }
    val activeDeliveries = myOrders.filter { !listOf("Delivered", "Cancelled", "Unable to Deliver").contains(it.status) }
    val deliveredOrders = myOrders.filter { it.status == "Delivered" }

    val filteredList = when (deliveryFilter) {
        "available" -> availableOrders
        "active" -> activeDeliveries
        "completed" -> deliveredOrders
        else -> myOrders
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CreamBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ── Rider Portal Header ──
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DeepForest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFFD9F27C)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🛵", fontSize = 20.sp)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Beerfood Rider", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White)
                                Text("DELIVERY PARTNER PORTAL", fontSize = 10.sp, color = Color(0xFFADC4B8), fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                            }
                        }

                        // Availability chip
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(if (isOnline) Color(0xFF1B5E20) else Color(0xFF424242))
                                .clickable {
                                    repository.toggleRiderOnline(selectedRider, !isOnline)
                                    Toast.makeText(context, if (!isOnline) "You are now ONLINE" else "You are now OFFLINE", Toast.LENGTH_SHORT).show()
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isOnline) Color(0xFF76FF03) else Color.Gray)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isOnline) "Online" else "Offline",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Rider Selector Dropdown
                    var dropdownExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = !dropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = "Signed In: $selectedRider",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFFADC4B8),
                                unfocusedBorderColor = Color.White.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            riderNames.forEach { name ->
                                DropdownMenuItem(
                                    text = { Text(name) },
                                    onClick = {
                                        selectedRider = name
                                        dropdownExpanded = false
                                        Toast.makeText(context, "Switched profile to $name", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Stats Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RiderStatCard(title = "Available", value = "${availableOrders.size}", modifier = Modifier.weight(1f))
                RiderStatCard(title = "My Active", value = "${activeDeliveries.size}", modifier = Modifier.weight(1f))
                RiderStatCard(title = "Delivered", value = "${deliveredOrders.size}", modifier = Modifier.weight(1f))
            }
        }

        // Filter tabs (Available pool, Active deliveries, Completed)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(
                    "active" to "My Active (${activeDeliveries.size})",
                    "available" to "Available Pool (${availableOrders.size})",
                    "completed" to "Delivered (${deliveredOrders.size})"
                ).forEach { (key, label) ->
                    val isSelected = deliveryFilter == key
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(if (isSelected) ForestGreen else SurfaceCard)
                            .border(1.dp, if (isSelected) ForestGreen else LineBorder, RoundedCornerShape(99.dp))
                            .clickable { deliveryFilter = key }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else InkDark
                        )
                    }
                }
            }
        }

        // Delivery orders list
        if (filteredList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder)
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🛵", fontSize = 42.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (deliveryFilter == "available") "No unassigned delivery orders" else "No orders in this tab",
                                fontWeight = FontWeight.Bold,
                                color = InkDark
                            )
                            Text(
                                text = if (deliveryFilter == "available") "New customer orders will appear here in real-time."
                                else "Check the Available Pool tab to accept fresh delivery requests.",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        }
                    }
                }
            }
        } else {
            items(filteredList) { order ->
                if (deliveryFilter == "available") {
                    // Available order card with Accept / Decline
                    AvailableOrderCard(
                        order = order,
                        onAccept = {
                            repository.acceptDelivery(order.id, selectedRider)
                            Toast.makeText(context, "Order ${order.orderNumber} accepted by $selectedRider!", Toast.LENGTH_SHORT).show()
                            deliveryFilter = "active"
                        },
                        onDecline = {
                            Toast.makeText(context, "Order ${order.orderNumber} declined", Toast.LENGTH_SHORT).show()
                        }
                    )
                } else {
                    RiderOrderCard(
                        order = order,
                        onStatusUpdate = { newStatus ->
                            repository.updateOrderStatus(order.id, newStatus)
                            Toast.makeText(context, "Order ${order.orderNumber} updated to $newStatus", Toast.LENGTH_SHORT).show()
                        },
                        onDecline = {
                            repository.declineDelivery(order.id, selectedRider)
                            Toast.makeText(context, "Delivery released back to available pool", Toast.LENGTH_SHORT).show()
                        },
                        onUpdateLocation = {
                            orderToUpdateLocation = order
                        },
                        onCallCustomer = {
                            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${order.phone}"))
                            context.startActivity(dialIntent)
                        },
                        onCopyAddress = {
                            clipboardManager.setText(AnnotatedString(order.address))
                            Toast.makeText(context, "Address copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        onOpenMap = {
                            val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + URLEncoder.encode(order.address, "UTF-8"))
                            val mapIntent = Intent(Intent.ACTION_VIEW, uri)
                            context.startActivity(mapIntent)
                        },
                        onRequestSupport = {
                            showSupportDialogForOrder = order
                        }
                    )
                }
            }
        }
    }

    // Live Location Update Dialog
    orderToUpdateLocation?.let { order ->
        var customLocation by remember { mutableStateOf(order.location?.area ?: "Gulberg Main Blvd") }
        val presets = listOf(
            "Departing store with hot order",
            "On Main Boulevard, Gulberg",
            "Near Kalma Chowk Roundabout",
            "Entering customer neighborhood",
            "Arrived at building gate / house"
        )

        AlertDialog(
            onDismissRequest = { orderToUpdateLocation = null },
            icon = { Icon(Icons.Default.MyLocation, contentDescription = null, tint = ForestGreen) },
            title = { Text("Update Live Delivery Location", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Updating location reflects immediately on customer's real-time tracker.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = customLocation,
                        onValueChange = { customLocation = it },
                        label = { Text("Current Location / Landmark") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Quick Location Presets:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    Spacer(modifier = Modifier.height(4.dp))

                    presets.forEach { preset ->
                        Text(
                            text = "📍 $preset",
                            fontSize = 12.sp,
                            color = ForestGreen,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { customLocation = preset }
                                .padding(vertical = 3.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customLocation.isNotBlank()) {
                            repository.updateOrderLocation(order.id, customLocation.trim())
                            Toast.makeText(context, "Live location updated!", Toast.LENGTH_SHORT).show()
                            orderToUpdateLocation = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Update Location")
                }
            },
            dismissButton = {
                TextButton(onClick = { orderToUpdateLocation = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Support Ticket Dialog
    showSupportDialogForOrder?.let { order ->
        var issueType by remember { mutableStateOf("Payment or collection") }
        var supportMessage by remember { mutableStateOf("") }
        val issueOptions = listOf("Payment or collection", "Address not found", "Customer unreachable", "Food damaged/spilled", "Other issue")

        AlertDialog(
            onDismissRequest = { showSupportDialogForOrder = null },
            title = { Text("Report Issue for ${order.orderNumber}", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Select issue category:", fontSize = 12.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(6.dp))

                    var issueExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = issueExpanded,
                        onExpandedChange = { issueExpanded = !issueExpanded }
                    ) {
                        OutlinedTextField(
                            value = issueType,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = issueExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = issueExpanded,
                            onDismissRequest = { issueExpanded = false }
                        ) {
                            issueOptions.forEach { opt ->
                                DropdownMenuItem(
                                    text = { Text(opt) },
                                    onClick = {
                                        issueType = opt
                                        issueExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = supportMessage,
                        onValueChange = { supportMessage = it },
                        label = { Text("Describe the situation") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (supportMessage.isNotBlank()) {
                            repository.fileSupportTicket(
                                rider = selectedRider,
                                orderId = order.id,
                                orderNumber = order.orderNumber,
                                issue = issueType,
                                message = supportMessage
                            )
                            Toast.makeText(context, "Support ticket submitted to admin", Toast.LENGTH_SHORT).show()
                            showSupportDialogForOrder = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Submit Ticket")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSupportDialogForOrder = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AvailableOrderCard(
    order: Order,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(order.orderNumber, fontWeight = FontWeight.Black, fontSize = 16.sp, color = ForestGreen)
                    Text("New Request · ${order.createdAt.take(16).replace("T", " ")}", fontSize = 11.sp, color = TextMuted)
                }
                StatusBadge(status = "New")
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = LineBorder)

            Text("DESTINATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextMuted)
            Text(order.address, fontSize = 13.sp, color = InkDark, fontWeight = FontWeight.Medium)

            Spacer(modifier = Modifier.height(6.dp))
            Text("ITEMS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextMuted)
            order.items.forEach { item ->
                Text("• ${item.emoji} ${item.name} × ${item.quantity}", fontSize = 12.sp, color = InkDark)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Payout / Total: ${formatPrice(order.total)} (${order.payment})",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = InkDark
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = LineBorder)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("✓ Accept Delivery", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onDecline,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted)
                ) {
                    Text("Decline", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun RiderStatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Black, color = InkDark)
        }
    }
}

@Composable
fun RiderOrderCard(
    order: Order,
    onStatusUpdate: (String) -> Unit,
    onDecline: () -> Unit,
    onUpdateLocation: () -> Unit,
    onCallCustomer: () -> Unit,
    onCopyAddress: () -> Unit,
    onOpenMap: () -> Unit,
    onRequestSupport: () -> Unit
) {
    val isComplete = listOf("Delivered", "Cancelled", "Unable to Deliver").contains(order.status)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Card Top Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(order.orderNumber, fontWeight = FontWeight.Black, fontSize = 16.sp, color = ForestGreen)
                    Text("Placed: ${order.createdAt.take(16).replace("T", " ")}", fontSize = 11.sp, color = TextMuted)
                }
                StatusBadge(status = order.status)
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = LineBorder)

            // Customer Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("CUSTOMER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    Text(order.customerName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = InkDark)
                    Text(order.phone, fontSize = 12.sp, color = TextMuted)
                }
                OutlinedButton(
                    onClick = onCallCustomer,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Call, contentDescription = "Call", tint = ForestGreen, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Call", color = ForestGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Address Row
            Text("DELIVERY ADDRESS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextMuted)
            Text(order.address, fontSize = 13.sp, color = InkDark)

            if (order.location?.area?.isNotEmpty() == true) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MyLocation, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Rider Location: ${order.location.area}", fontSize = 11.sp, color = ForestGreen, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onOpenMap,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Directions, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Directions ↗", fontSize = 11.sp, color = ForestGreen)
                }
                OutlinedButton(
                    onClick = onCopyAddress,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy", fontSize = 11.sp, color = TextMuted)
                }
                if (!isComplete) {
                    OutlinedButton(
                        onClick = onUpdateLocation,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Update GPS", fontSize = 11.sp, color = ForestGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Items breakdown
            Text("ITEMS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextMuted)
            order.items.forEach { item ->
                Text("• ${item.emoji} ${item.name} × ${item.quantity}", fontSize = 12.sp, color = InkDark)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Payment summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (order.payment == "Cash on Delivery") "COLLECT CASH ON DELIVERY" else "PREPAID VERIFICATION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (order.payment == "Cash on Delivery") DangerRed else ForestGreen
                    )
                    Text(
                        text = if (order.payment == "Cash on Delivery") formatPrice(order.total) else "${order.payment} (${order.paymentStatus})",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = InkDark
                    )
                }

                PaymentStatusBadge(paymentStatus = order.paymentStatus)
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = LineBorder)

            // Action Buttons
            if (!isComplete) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    when (order.status) {
                        "New", "Confirmed", "Preparing", "Ready for Pickup" -> {
                            Button(
                                onClick = { onStatusUpdate("Picked Up") },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Mark Picked Up", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = onDecline,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted)
                            ) {
                                Text("Release", fontSize = 11.sp)
                            }
                        }
                        "Picked Up" -> {
                            Button(
                                onClick = { onStatusUpdate("On the Way") },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Start Delivery", fontWeight = FontWeight.Bold)
                            }
                        }
                        "On the Way" -> {
                            Button(
                                onClick = { onStatusUpdate("Delivered") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF267343)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("✓ Mark Delivered", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = { onStatusUpdate("Unable to Deliver") },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed)
                    ) {
                        Text("Issue", fontSize = 12.sp)
                    }

                    IconButton(onClick = onRequestSupport) {
                        Icon(Icons.Default.HelpOutline, contentDescription = "Support", tint = TextMuted)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("✓ Delivery finalized", color = ForestGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onRequestSupport) {
                        Text("Report Issue", fontSize = 11.sp, color = TextMuted)
                    }
                }
            }
        }
    }
}
