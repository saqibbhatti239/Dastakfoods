package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerRedLight
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestLight
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.InfoBlueText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenText
import com.example.ui.theme.WarningYellow
import com.example.ui.theme.WarningYellowText
import java.text.NumberFormat
import java.util.Locale

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (status) {
        "New" -> WarningYellow to WarningYellowText
        "Confirmed", "Preparing" -> InfoBlue to InfoBlueText
        "Ready for Pickup", "Picked Up", "On the Way" -> ForestLight to ForestGreen
        "Delivered" -> SuccessGreen to SuccessGreenText
        "Cancelled", "Unable to Deliver" -> DangerRedLight to DangerRed
        else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(99.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = status,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun PaymentStatusBadge(
    paymentStatus: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (paymentStatus) {
        "Verified" -> SuccessGreen to SuccessGreenText
        "Pending manual verification" -> WarningYellow to WarningYellowText
        "Rejected" -> DangerRedLight to DangerRed
        "Pay on delivery" -> InfoBlue to InfoBlueText
        else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = paymentStatus,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

fun formatPrice(amount: Int): String {
    val formatter = NumberFormat.getNumberInstance(Locale.US)
    return "Rs. ${formatter.format(amount)}"
}
