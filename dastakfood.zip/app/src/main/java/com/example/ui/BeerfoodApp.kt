package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Motorcycle
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.BeerfoodRepository
import com.example.model.AppRole
import com.example.ui.admin.AdminScreen
import com.example.ui.auth.RoleAuthScreen
import com.example.ui.customer.CustomerScreen
import com.example.ui.rider.RiderScreen
import com.example.ui.theme.BeerfoodTheme
import com.example.ui.theme.BrightLime
import com.example.ui.theme.DeepForest
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestLight
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.google.firebase.auth.FirebaseAuth

/**
 * Navigation destination routes for the Beerfood connected delivery platform.
 */
object BeerfoodDestinations {
    const val AUTH = "role_auth"
    const val CUSTOMER = "beerfood_customer"
    const val ADMIN = "beerfood_admin"
    const val RIDER = "beerfood_rider"
}

@Composable
fun BeerfoodApp() {
    val repository = remember { BeerfoodRepository.getInstance() }
    val context = LocalContext.current
    val currentUser by repository.currentUser.collectAsState()

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: BeerfoodDestinations.CUSTOMER

    // Determine active role from current navigation route
    val activeRole = when (currentRoute) {
        BeerfoodDestinations.ADMIN -> AppRole.ADMIN
        BeerfoodDestinations.RIDER -> AppRole.RIDER
        else -> AppRole.CUSTOMER
    }

    // Initialize Firestore enterprise database synchronization & check signed-in user role
    LaunchedEffect(Unit) {
        repository.initFirestore(context)
        val firebaseUser = FirebaseAuth.getInstance().currentUser
        if (firebaseUser != null) {
            repository.checkUserRoleInFirestore(firebaseUser.uid, "customer") { resolvedRole ->
                val targetDestination = when (resolvedRole.lowercase()) {
                    "admin" -> BeerfoodDestinations.ADMIN
                    "rider" -> BeerfoodDestinations.RIDER
                    else -> BeerfoodDestinations.CUSTOMER
                }
                if (targetDestination != currentRoute) {
                    navController.navigate(targetDestination) {
                        popUpTo(BeerfoodDestinations.CUSTOMER) { saveState = true }
                        launchSingleTop = true
                    }
                }
            }
        }
    }

    // Handle system back navigation
    BackHandler(enabled = currentRoute == BeerfoodDestinations.ADMIN || currentRoute == BeerfoodDestinations.RIDER) {
        navController.navigate(BeerfoodDestinations.CUSTOMER) {
            popUpTo(BeerfoodDestinations.CUSTOMER) { inclusive = false }
            launchSingleTop = true
        }
    }

    val isAuthScreen = currentRoute == BeerfoodDestinations.AUTH

    BeerfoodTheme {
        Scaffold(
            contentWindowInsets = WindowInsets.systemBars,
            topBar = {
                if (!isAuthScreen) {
                    // Unified Platform Role Switcher Header
                    Surface(
                        color = when (activeRole) {
                            AppRole.CUSTOMER -> DeepForest
                            AppRole.ADMIN -> Color(0xFF0D3B31)
                            AppRole.RIDER -> Color(0xFF0F4538)
                        },
                        tonalElevation = 4.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Active App Pill showing exact name
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(BrightLime.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = activeRole.appTitle,
                                    color = BrightLime,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            Spacer(modifier = Modifier.weight(1f))

                            // Switch App / Role-Based Login Screen Link
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color.White.copy(alpha = 0.15f))
                                    .clickable {
                                        navController.navigate(BeerfoodDestinations.AUTH) {
                                            launchSingleTop = true
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                                    .testTag("open_role_auth_button")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.SwapHoriz,
                                        contentDescription = "Switch Role",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (currentUser != null) currentUser!!.name.take(12) else "Role Sign-In",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            },
            bottomBar = {
                if (!isAuthScreen) {
                    NavigationBar(
                        containerColor = SurfaceCard,
                        tonalElevation = 8.dp
                    ) {
                        // 1. Beerfood Customer
                        NavigationBarItem(
                            selected = currentRoute == BeerfoodDestinations.CUSTOMER,
                            onClick = {
                                if (currentRoute != BeerfoodDestinations.CUSTOMER) {
                                    navController.navigate(BeerfoodDestinations.CUSTOMER) {
                                        popUpTo(BeerfoodDestinations.CUSTOMER) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    Icons.Default.Restaurant,
                                    contentDescription = "Beerfood Customer",
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    "Beerfood Customer",
                                    fontWeight = if (currentRoute == BeerfoodDestinations.CUSTOMER) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 10.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ForestGreen,
                                selectedTextColor = ForestGreen,
                                indicatorColor = ForestLight,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            )
                        )

                        // 2. Beerfood Rider
                        NavigationBarItem(
                            selected = currentRoute == BeerfoodDestinations.RIDER,
                            onClick = {
                                if (currentRoute != BeerfoodDestinations.RIDER) {
                                    navController.navigate(BeerfoodDestinations.RIDER) {
                                        popUpTo(BeerfoodDestinations.CUSTOMER) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    Icons.Default.Motorcycle,
                                    contentDescription = "Beerfood Rider",
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    "Beerfood Rider",
                                    fontWeight = if (currentRoute == BeerfoodDestinations.RIDER) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 10.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ForestGreen,
                                selectedTextColor = ForestGreen,
                                indicatorColor = ForestLight,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            )
                        )

                        // 3. Beerfood Admin
                        NavigationBarItem(
                            selected = currentRoute == BeerfoodDestinations.ADMIN,
                            onClick = {
                                if (currentRoute != BeerfoodDestinations.ADMIN) {
                                    navController.navigate(BeerfoodDestinations.ADMIN) {
                                        popUpTo(BeerfoodDestinations.CUSTOMER) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    Icons.Default.AdminPanelSettings,
                                    contentDescription = "Beerfood Admin",
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    "Beerfood Admin",
                                    fontWeight = if (currentRoute == BeerfoodDestinations.ADMIN) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 10.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ForestGreen,
                                selectedTextColor = ForestGreen,
                                indicatorColor = ForestLight,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = BeerfoodDestinations.CUSTOMER,
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable(BeerfoodDestinations.AUTH) {
                        RoleAuthScreen(
                            repository = repository,
                            selectedRole = activeRole,
                            onRoleChanged = { /* Role preview selection handled inside */ },
                            onNavigateToDashboard = { role ->
                                val target = when (role.lowercase()) {
                                    "admin" -> BeerfoodDestinations.ADMIN
                                    "rider" -> BeerfoodDestinations.RIDER
                                    else -> BeerfoodDestinations.CUSTOMER
                                }
                                navController.navigate(target) {
                                    popUpTo(BeerfoodDestinations.AUTH) { inclusive = true }
                                    launchSingleTop = true
                                }
                            },
                            onBack = {
                                if (navController.previousBackStackEntry != null) {
                                    navController.popBackStack()
                                } else {
                                    navController.navigate(BeerfoodDestinations.CUSTOMER) {
                                        popUpTo(BeerfoodDestinations.AUTH) { inclusive = true }
                                    }
                                }
                            }
                        )
                    }

                    composable(BeerfoodDestinations.CUSTOMER) {
                        CustomerScreen(repository = repository)
                    }

                    composable(BeerfoodDestinations.RIDER) {
                        RiderScreen(repository = repository)
                    }

                    composable(BeerfoodDestinations.ADMIN) {
                        AdminScreen(repository = repository)
                    }
                }
            }
        }
    }
}
