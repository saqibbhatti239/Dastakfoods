package com.example.ui.auth

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Motorcycle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.BeerfoodRepository
import com.example.model.AppRole
import com.example.ui.theme.BrightLime
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.DeepForest
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestLight
import com.example.ui.theme.InkDark
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarmOrange
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch

@Composable
fun RoleAuthScreen(
    repository: BeerfoodRepository,
    selectedRole: AppRole = AppRole.CUSTOMER,
    onRoleChanged: (AppRole) -> Unit = {},
    onEnterApp: ((AppRole) -> Unit)? = null,
    onNavigateToDashboard: ((String) -> Unit)? = null,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val currentUser by repository.currentUser.collectAsState()

    var currentSelectedRole by remember { mutableStateOf(selectedRole) }
    var phoneInput by remember { mutableStateOf(currentUser?.phone ?: "") }
    var nameInput by remember { mutableStateOf(currentUser?.name ?: "") }
    var otpInput by remember { mutableStateOf("") }
    var isOtpSent by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var authMode by remember { mutableStateOf("phone") } // "phone" or "role_select"

    val credentialManager = remember { CredentialManager.create(context) }

    fun routeToRole(roleStr: String) {
        if (onNavigateToDashboard != null) {
            onNavigateToDashboard(roleStr)
        } else if (onEnterApp != null) {
            val appRole = when (roleStr.lowercase()) {
                "admin" -> AppRole.ADMIN
                "rider" -> AppRole.RIDER
                else -> AppRole.CUSTOMER
            }
            onEnterApp(appRole)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CreamBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Back button if navigation allows returning
        if (onBack != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start
            ) {
                TextButton(onClick = onBack) {
                    Text("← Back to App", color = ForestGreen, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Brand Logo
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ForestGreen),
                contentAlignment = Alignment.Center
            ) {
                Text("B", color = BrightLime, fontSize = 26.sp, fontWeight = FontWeight.Black)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = ForestGreen, fontWeight = FontWeight.Black, fontSize = 28.sp)) {
                        append("beer")
                    }
                    withStyle(SpanStyle(color = WarmOrange, fontWeight = FontWeight.Black, fontSize = 28.sp)) {
                        append("food")
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Connected Delivery Platform • Unified Backend",
            fontSize = 12.sp,
            color = TextMuted,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(24.dp))

        // 3-App Switcher & Selector
        Text(
            text = "Select App to Enter",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = InkDark,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AppRoleOptionCard(
                role = AppRole.CUSTOMER,
                icon = Icons.Default.Restaurant,
                title = "Customer",
                sub = "Browse & Track",
                isSelected = currentSelectedRole == AppRole.CUSTOMER,
                onClick = {
                    currentSelectedRole = AppRole.CUSTOMER
                    onRoleChanged(AppRole.CUSTOMER)
                },
                modifier = Modifier.weight(1f)
            )
            AppRoleOptionCard(
                role = AppRole.RIDER,
                icon = Icons.Default.Motorcycle,
                title = "Rider",
                sub = "Delivery Pool",
                isSelected = currentSelectedRole == AppRole.RIDER,
                onClick = {
                    currentSelectedRole = AppRole.RIDER
                    onRoleChanged(AppRole.RIDER)
                },
                modifier = Modifier.weight(1f)
            )
            AppRoleOptionCard(
                role = AppRole.ADMIN,
                icon = Icons.Default.AdminPanelSettings,
                title = "Admin",
                sub = "Manage Store",
                isSelected = currentSelectedRole == AppRole.ADMIN,
                onClick = {
                    currentSelectedRole = AppRole.ADMIN
                    onRoleChanged(AppRole.ADMIN)
                },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Dedicated Role & Login Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header with Exact App Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(ForestLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(currentSelectedRole.icon, fontSize = 20.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = currentSelectedRole.appTitle,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = ForestGreen
                        )
                        Text(
                            text = when (currentSelectedRole) {
                                AppRole.CUSTOMER -> "Customer portal & order tracker"
                                AppRole.ADMIN -> "Merchant catalog & dispatch console"
                                AppRole.RIDER -> "Delivery pool & milestone updates"
                            },
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 14.dp),
                    color = Color.LightGray.copy(alpha = 0.3f)
                )

                // Current Session Banner if logged in
                if (currentUser != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(ForestLight)
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Active", tint = ForestGreen)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "Signed In: ${currentUser?.name}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = InkDark
                                )
                                Text(
                                    "Role: ${currentUser?.role?.uppercase()} • Phone: ${currentUser?.phone}",
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                            }
                            TextButton(onClick = { repository.logout() }) {
                                Text("Switch", color = ForestGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val user = currentUser
                            if (user != null) {
                                repository.checkUserRoleInFirestore(user.id, currentSelectedRole.name.lowercase()) { resolvedRole ->
                                    routeToRole(resolvedRole)
                                }
                            } else {
                                routeToRole(currentSelectedRole.name.lowercase())
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("enter_app_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                    ) {
                        Text(
                            "Enter ${currentSelectedRole.appTitle}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Sign In / Registration Options
                Text(
                    text = if (currentUser == null) "Sign In / Register to Continue" else "Change Sign-In Account",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = InkDark
                )
                Spacer(modifier = Modifier.height(10.dp))

                // 1. Google Sign-In Button (Mandatory Firebase CredentialManager integration)
                OutlinedButton(
                    onClick = {
                        isLoading = true
                        statusMessage = null
                        coroutineScope.launch {
                            try {
                                val webClientId = try {
                                    context.getString(R.string.default_web_client_id)
                                } catch (e: Exception) {
                                    ""
                                }
                                if (webClientId.isBlank()) {
                                    statusMessage = "Google Sign-In configuration ready. Use phone OTP or demo code."
                                    isLoading = false
                                    return@launch
                                }
                                val googleIdOption = GetSignInWithGoogleOption.Builder(webClientId)
                                    .build()
                                val request = GetCredentialRequest.Builder()
                                    .addCredentialOption(googleIdOption)
                                    .build()
                                val result = credentialManager.getCredential(request = request, context = context)
                                val credential = result.credential
                                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                    val tokenCred = GoogleIdTokenCredential.createFrom(credential.data)
                                    repository.signInWithGoogle(
                                        idToken = tokenCred.idToken,
                                        role = currentSelectedRole.name.lowercase(),
                                        onRoleResolved = { firestoreRole, user ->
                                            Toast.makeText(context, "Signed in as ${user.name} (${firestoreRole.uppercase()})", Toast.LENGTH_SHORT).show()
                                            routeToRole(firestoreRole)
                                        },
                                        onError = { e ->
                                            statusMessage = e.localizedMessage ?: "Google sign-in error."
                                        }
                                    )
                                }
                            } catch (e: GetCredentialCancellationException) {
                                statusMessage = "Sign-in cancelled. Select an account or use Phone OTP."
                            } catch (e: Exception) {
                                statusMessage = "Google Sign-in: ${e.localizedMessage ?: "Provider not ready, use Phone OTP"}"
                            } finally {
                                isLoading = false
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("google_signin_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("G", fontWeight = FontWeight.Black, fontSize = 18.sp, color = ForestGreen)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "Sign in with Google",
                            color = InkDark,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HorizontalDivider(modifier = Modifier.weight(1f), color = Color.LightGray.copy(alpha = 0.5f))
                    Text(
                        "  OR PHONE OTP  ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                    HorizontalDivider(modifier = Modifier.weight(1f), color = Color.LightGray.copy(alpha = 0.5f))
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 2. Phone Number OTP Form
                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it },
                    label = { Text("Phone Number") },
                    placeholder = { Text("+92 300 1234567") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = "Phone", tint = ForestGreen) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("phone_input")
                )

                if (!isOtpSent) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Full Name (Optional for registration)") },
                        placeholder = { Text(if (currentSelectedRole == AppRole.RIDER) "e.g. Asad Ali" else "e.g. Saqib Bhatti") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = "Name", tint = ForestGreen) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("name_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (phoneInput.trim().length < 10) {
                                statusMessage = "Please enter a valid phone number with country/area code."
                                return@Button
                            }
                            isOtpSent = true
                            statusMessage = "Verification code requested. Use test OTP 583104 or any 6-digit code."
                            Toast.makeText(context, "Code sent to $phoneInput", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("send_otp_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                    ) {
                        Text("Send OTP Verification Code", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = otpInput,
                        onValueChange = { if (it.length <= 6) otpInput = it },
                        label = { Text("6-Digit Verification Code") },
                        placeholder = { Text("583104") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "OTP", tint = WarmOrange) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("otp_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (otpInput.trim().length != 6) {
                                statusMessage = "Enter the 6-digit verification code."
                                return@Button
                            }
                            isLoading = true
                            val result = repository.verifyPhoneOtp(
                                phone = phoneInput,
                                code = otpInput,
                                name = nameInput,
                                role = currentSelectedRole.name.lowercase(),
                                onRoleResolved = { firestoreRole, user ->
                                    Toast.makeText(context, "Welcome to ${currentSelectedRole.appTitle}!", Toast.LENGTH_SHORT).show()
                                    routeToRole(firestoreRole)
                                }
                            )
                            isLoading = false
                            result.onFailure { err ->
                                statusMessage = err.message ?: "Verification failed."
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("verify_otp_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WarmOrange)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        } else {
                            Text("Verify Code & Enter ${currentSelectedRole.appTitle}", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { isOtpSent = false }) {
                            Text("Change phone number", fontSize = 12.sp, color = TextMuted)
                        }
                        TextButton(onClick = {
                            otpInput = "583104"
                            Toast.makeText(context, "Test code 583104 filled", Toast.LENGTH_SHORT).show()
                        }) {
                            Text("Fill test code (583104)", fontSize = 12.sp, color = ForestGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Transparent Provider Notice
                Spacer(modifier = Modifier.height(14.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF0F4F2))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = "Notice",
                            tint = ForestGreen,
                            modifier = Modifier
                                .size(16.dp)
                                .padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Live carrier SMS OTP requires Twilio or Firebase Phone Auth secrets configured in backend settings. For development and testing, code 583104 or any 6 digits is accepted.",
                            fontSize = 11.sp,
                            color = InkDark.copy(alpha = 0.7f),
                            lineHeight = 15.sp
                        )
                    }
                }

                if (statusMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = statusMessage!!,
                        fontSize = 12.sp,
                        color = WarmOrange,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Entry without login for testing all 3 apps
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Quick Demo Access (Explore All 3 Apps):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            repository.loginDemoUser("Saqib Customer", "+92 300 1234567", "customer") { role, _ ->
                                routeToRole(role)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                    ) {
                        Text("Customer", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ForestGreen)
                    }
                    OutlinedButton(
                        onClick = {
                            repository.loginDemoUser("Kamran Rider", "+92 321 9876543", "rider") { role, _ ->
                                routeToRole(role)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                    ) {
                        Text("Rider", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = WarmOrange)
                    }
                    OutlinedButton(
                        onClick = {
                            repository.loginDemoUser("Beerfood Store Owner", "+92 300 0000000", "admin") { role, _ ->
                                routeToRole(role)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                    ) {
                        Text("Admin", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun AppRoleOptionCard(
    role: AppRole,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    sub: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) ForestGreen else SurfaceCard
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp),
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) ForestGreen else Color.LightGray.copy(alpha = 0.4f),
                shape = RoundedCornerShape(14.dp)
            )
            .testTag("role_card_${role.name.lowercase()}")
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                icon,
                contentDescription = title,
                tint = if (isSelected) BrightLime else ForestGreen,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                title,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (isSelected) Color.White else InkDark
            )
            Text(
                sub,
                fontSize = 9.sp,
                color = if (isSelected) Color.White.copy(alpha = 0.8f) else TextMuted
            )
        }
    }
}
