package com.example.ui.admin

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Motorcycle
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BeerfoodRepository
import com.example.model.Order
import com.example.model.Product
import com.example.model.SupportTicket
import com.example.ui.components.PaymentStatusBadge
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatPrice
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DeepForest
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestLight
import com.example.ui.theme.InkDark
import com.example.ui.theme.LineBorder
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarmOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    repository: BeerfoodRepository,
    modifier: Modifier = Modifier
) {
    val categories by repository.categories.collectAsState()
    val products by repository.products.collectAsState()
    val orders by repository.orders.collectAsState()
    val riderStatuses by repository.riderStatuses.collectAsState()
    val supportTickets by repository.supportTickets.collectAsState()
    val context = LocalContext.current

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Overview", "Orders", "Menu", "Payments", "Riders", "Reports")
    val tabIcons = listOf(
        Icons.Default.Dashboard,
        Icons.Default.Receipt,
        Icons.Default.MenuBook,
        Icons.Default.Payments,
        Icons.Default.Motorcycle,
        Icons.Default.Assessment
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CreamBackground)
    ) {
        // Top Admin Header
        Surface(
            color = DeepForest,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFD9F27C)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("B", fontWeight = FontWeight.Black, fontSize = 20.sp, color = DeepForest)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Beerfood Admin", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
                            Text("STORE MANAGEMENT CONSOLE", color = Color(0xFFADC4B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(Color.White.copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Store Admin", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable tab row
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = Color.White,
                    edgePadding = 0.dp,
                    indicator = {},
                    divider = {}
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        val isSelected = selectedTab == index
                        Tab(
                            selected = isSelected,
                            onClick = { selectedTab = index },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(99.dp))
                                        .background(if (isSelected) Color.White else Color.Transparent)
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        tabIcons[index],
                                        contentDescription = null,
                                        tint = if (isSelected) DeepForest else Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        title,
                                        color = if (isSelected) DeepForest else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }

        // Tab Content
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedTab) {
                0 -> AdminOverviewTab(orders, products, onGoToOrders = { selectedTab = 1 })
                1 -> AdminOrdersTab(orders, repository)
                2 -> AdminMenuTab(categories, products, repository)
                3 -> AdminPaymentsTab(orders, repository)
                4 -> AdminRidersTab(orders, riderStatuses, supportTickets, repository)
                5 -> AdminReportsTab(orders)
            }
        }
    }
}

@Composable
fun AdminOverviewTab(
    orders: List<Order>,
    products: List<Product>,
    onGoToOrders: () -> Unit
) {
    val totalSales = orders.filter { it.status != "Cancelled" }.sumOf { it.total }
    val pendingNew = orders.count { it.status == "New" }
    val availableProducts = products.count { it.available }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Good day, Admin 👋", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = InkDark)
            Text("Here is what is happening with your store today.", fontSize = 12.sp, color = TextMuted)
        }

        // Stats grid
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AdminMetricCard(
                    title = "Orders",
                    value = "${orders.size}",
                    sub = "Total store orders",
                    emoji = "🧾",
                    modifier = Modifier.weight(1f)
                )
                AdminMetricCard(
                    title = "Sales",
                    value = formatPrice(totalSales),
                    sub = "Excluding cancelled",
                    emoji = "💰",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AdminMetricCard(
                    title = "Attention",
                    value = "$pendingNew",
                    sub = "New pending orders",
                    emoji = "🔔",
                    modifier = Modifier.weight(1f)
                )
                AdminMetricCard(
                    title = "Menu Items",
                    value = "${products.size}",
                    sub = "$availableProducts in stock",
                    emoji = "🍽️",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Recent Orders Panel
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Recent Orders", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkDark)
                        TextButton(onClick = onGoToOrders) {
                            Text("All orders →", color = ForestGreen, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (orders.isEmpty()) {
                        Text("No orders placed yet.", fontSize = 12.sp, color = TextMuted)
                    } else {
                        orders.take(4).forEach { order ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(order.orderNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ForestGreen)
                                    Text("${order.customerName} · ${formatPrice(order.total)}", fontSize = 12.sp, color = InkDark)
                                }
                                StatusBadge(status = order.status)
                            }
                            HorizontalDivider(color = LineBorder.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }

        // Popular catalog items
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Top Catalog Items", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    Spacer(modifier = Modifier.height(6.dp))

                    products.take(4).forEach { product ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(product.emoji, fontSize = 24.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(product.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = InkDark)
                                    Text("${product.category} · ${formatPrice(product.price)}", fontSize = 11.sp, color = TextMuted)
                                }
                            }
                            Text(
                                if (product.available) "In Stock" else "Sold Out",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (product.available) SuccessGreen else DangerRed
                            )
                        }
                        HorizontalDivider(color = LineBorder.copy(alpha = 0.5f))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminOrdersTab(
    orders: List<Order>,
    repository: BeerfoodRepository
) {
    var filterStatus by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var orderToAssignRider by remember { mutableStateOf<Order?>(null) }
    val context = LocalContext.current

    val statuses = listOf("All", "New", "Confirmed", "Preparing", "Ready for Pickup", "Picked Up", "On the Way", "Delivered", "Cancelled", "Unable to Deliver")

    val filtered = orders.filter { o ->
        val statusMatch = filterStatus == "All" || o.status == filterStatus
        val queryMatch = searchQuery.isBlank() ||
                o.orderNumber.contains(searchQuery, ignoreCase = true) ||
                o.customerName.contains(searchQuery, ignoreCase = true) ||
                o.phone.contains(searchQuery, ignoreCase = true)
        statusMatch && queryMatch
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Orders Management", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = InkDark)
            Text("Update statuses, assign delivery riders, and view details.", fontSize = 12.sp, color = TextMuted)
        }

        // Filters
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by order #, customer, phone") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Horizontal status chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(statuses) { s ->
                    val isSel = filterStatus == s
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(if (isSel) ForestGreen else SurfaceCard)
                            .border(1.dp, if (isSel) ForestGreen else LineBorder, RoundedCornerShape(99.dp))
                            .clickable { filterStatus = s }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = s,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSel) Color.White else InkDark
                        )
                    }
                }
            }
        }

        if (filtered.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No matching orders found.", color = TextMuted)
                }
            }
        } else {
            items(filtered) { order ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(order.orderNumber, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = ForestGreen)
                                Text("${order.customerName} (${order.phone})", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                            StatusBadge(status = order.status)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Address: ${order.address}", fontSize = 12.sp, color = TextMuted)
                        Text("Items: " + order.items.joinToString { "${it.emoji} ${it.name} x${it.quantity}" }, fontSize = 12.sp, color = InkDark)
                        Text("Payment: ${order.payment} (${order.paymentStatus}) · Total: ${formatPrice(order.total)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkDark)

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = LineBorder)

                        // Status changer + rider assign
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Status Dropdown
                            var statusMenuExpanded by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(
                                    onClick = { statusMenuExpanded = true },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("Status: ${order.status} ▾", fontSize = 11.sp, color = ForestGreen)
                                }
                                androidx.compose.material3.DropdownMenu(
                                    expanded = statusMenuExpanded,
                                    onDismissRequest = { statusMenuExpanded = false }
                                ) {
                                    listOf("New", "Confirmed", "Preparing", "Ready for Pickup", "Picked Up", "On the Way", "Delivered", "Cancelled", "Unable to Deliver").forEach { opt ->
                                        DropdownMenuItem(
                                            text = { Text(opt, fontSize = 12.sp) },
                                            onClick = {
                                                repository.updateOrderStatus(order.id, opt)
                                                statusMenuExpanded = false
                                                Toast.makeText(context, "Order marked as $opt", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }
                                }
                            }

                            // Rider Assign button
                            OutlinedButton(
                                onClick = { orderToAssignRider = order },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (order.rider.isNotEmpty()) "Rider: ${order.rider}" else "Assign Rider",
                                    fontSize = 11.sp,
                                    color = DeepForest
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Assign Rider Dialog
    orderToAssignRider?.let { order ->
        var inputRider by remember { mutableStateOf(order.rider.ifEmpty { "Rider 1" }) }
        val quickRiders = listOf("Rider 1", "Ali Khan", "Usman", "Hamza")

        AlertDialog(
            onDismissRequest = { orderToAssignRider = null },
            title = { Text("Assign Rider to ${order.orderNumber}", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Select or enter delivery rider name:", fontSize = 12.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = inputRider,
                        onValueChange = { inputRider = it },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Known Riders:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        quickRiders.forEach { r ->
                            Button(
                                onClick = { inputRider = r },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestLight),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(r, fontSize = 10.sp, color = ForestGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputRider.isNotBlank()) {
                            repository.assignRider(order.id, inputRider)
                            Toast.makeText(context, "Assigned to $inputRider", Toast.LENGTH_SHORT).show()
                            orderToAssignRider = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Assign")
                }
            },
            dismissButton = {
                TextButton(onClick = { orderToAssignRider = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMenuTab(
    categories: List<String>,
    products: List<Product>,
    repository: BeerfoodRepository
) {
    var activeCategory by remember { mutableStateOf("All") }
    var showAddProductDialog by remember { mutableStateOf(false) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val filteredProducts = products.filter {
        activeCategory == "All" || it.category.equals(activeCategory, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Menu & Items", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    Text("Manage food dishes, groceries, and prices.", fontSize = 12.sp, color = TextMuted)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = { showAddCategoryDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestLight),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("+ Category", fontSize = 11.sp, color = ForestGreen, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { showAddProductDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("+ Add Item", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Category tabs
        item {
            val allCats = listOf("All") + categories
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(allCats) { cat ->
                    val isSel = activeCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(if (isSel) ForestGreen else SurfaceCard)
                            .border(1.dp, if (isSel) ForestGreen else LineBorder, RoundedCornerShape(99.dp))
                            .clickable { activeCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else InkDark)
                    }
                }
            }
        }

        // Products list
        items(filteredProducts) { product ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Text(product.emoji, fontSize = 28.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(product.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = InkDark)
                            Text("${product.category} · ${formatPrice(product.price)}", fontSize = 12.sp, color = TextMuted)
                            if (product.description.isNotEmpty()) {
                                Text(product.description, fontSize = 11.sp, color = TextMuted, maxLines = 1)
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Availability Toggle
                        Button(
                            onClick = {
                                repository.toggleProductAvailability(product.id)
                                Toast.makeText(context, "${product.name} updated", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (product.available) ForestLight else Color(0xFFF1F2F0)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                if (product.available) "Available" else "Off",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (product.available) ForestGreen else Color.Gray
                            )
                        }

                        IconButton(
                            onClick = {
                                repository.deleteProduct(product.id)
                                Toast.makeText(context, "${product.name} deleted", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    // Add Product Dialog
    if (showAddProductDialog) {
        var pName by remember { mutableStateOf("") }
        var pPrice by remember { mutableStateOf("") }
        var pCat by remember { mutableStateOf(categories.firstOrNull() ?: "Burgers") }
        var pEmoji by remember { mutableStateOf("🍽️") }
        var pDesc by remember { mutableStateOf("") }
        var errorMsg by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddProductDialog = false },
            title = { Text("Add New Menu Item", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = pName,
                        onValueChange = { pName = it },
                        label = { Text("Item Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = pPrice,
                        onValueChange = { pPrice = it },
                        label = { Text("Price in Rs") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // Category picker
                    var catExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = catExpanded,
                        onExpandedChange = { catExpanded = !catExpanded }
                    ) {
                        OutlinedTextField(
                            value = pCat,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Category") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                            categories.forEach { c ->
                                DropdownMenuItem(text = { Text(c) }, onClick = { pCat = c; catExpanded = false })
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = pEmoji,
                        onValueChange = { pEmoji = it },
                        label = { Text("Emoji Icon") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = pDesc,
                        onValueChange = { pDesc = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )

                    if (errorMsg.isNotEmpty()) {
                        Text(errorMsg, color = DangerRed, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val priceInt = pPrice.toIntOrNull()
                        if (pName.isBlank() || priceInt == null || priceInt <= 0) {
                            errorMsg = "Enter valid item name and numeric price."
                            return@Button
                        }
                        val success = repository.addProduct(
                            name = pName,
                            category = pCat,
                            price = priceInt,
                            emoji = pEmoji,
                            description = pDesc
                        )
                        if (success) {
                            Toast.makeText(context, "$pName added!", Toast.LENGTH_SHORT).show()
                            showAddProductDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Add Item")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddProductDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add Category Dialog
    if (showAddCategoryDialog) {
        var catName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddCategoryDialog = false },
            title = { Text("Add New Category", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = catName,
                    onValueChange = { catName = it },
                    label = { Text("Category Name (e.g. Breakfast, Shakes)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (catName.isNotBlank()) {
                            repository.addCategory(catName)
                            Toast.makeText(context, "Category $catName added!", Toast.LENGTH_SHORT).show()
                            showAddCategoryDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCategoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AdminPaymentsTab(
    orders: List<Order>,
    repository: BeerfoodRepository
) {
    var paymentFilter by remember { mutableStateOf("All") }
    val context = LocalContext.current

    val pendingVerification = orders.filter { it.paymentStatus == "Pending manual verification" }
    val verifiedCount = orders.count { it.paymentStatus == "Verified" }
    val codCount = orders.count { it.payment == "Cash on Delivery" || it.paymentStatus == "Pay on delivery" }

    val filtered = orders.filter { o ->
        paymentFilter == "All" || o.paymentStatus == paymentFilter
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Payments Verification", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = InkDark)
            Text("Review Easypaisa, JazzCash, Bank Transfers and Cash on Delivery.", fontSize = 12.sp, color = TextMuted)
        }

        // Stats
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AdminMetricCard(
                    title = "Pending Review",
                    value = "${pendingVerification.size}",
                    sub = formatPrice(pendingVerification.sumOf { it.total }),
                    emoji = "⏳",
                    modifier = Modifier.weight(1f)
                )
                AdminMetricCard(
                    title = "Verified",
                    value = "$verifiedCount",
                    sub = "Payments approved",
                    emoji = "✓",
                    modifier = Modifier.weight(1f)
                )
                AdminMetricCard(
                    title = "Cash on Delivery",
                    value = "$codCount",
                    sub = "Pay on arrival",
                    emoji = "🚚",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Filter chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(
                    listOf(
                        "All" to "All",
                        "Pending manual verification" to "Awaiting Verification",
                        "Verified" to "Verified",
                        "Rejected" to "Rejected",
                        "Pay on delivery" to "Cash on Delivery"
                    )
                ) { (key, label) ->
                    val isSel = paymentFilter == key
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(if (isSel) ForestGreen else SurfaceCard)
                            .border(1.dp, if (isSel) ForestGreen else LineBorder, RoundedCornerShape(99.dp))
                            .clickable { paymentFilter = key }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else InkDark)
                    }
                }
            }
        }

        items(filtered) { order ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(order.orderNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ForestGreen)
                            Text("${order.customerName} · ${order.payment}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        PaymentStatusBadge(paymentStatus = order.paymentStatus)
                    }

                    if (order.transactionReference.isNotEmpty()) {
                        Text("Ref ID: ${order.transactionReference}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    }
                    Text("Total: ${formatPrice(order.total)}", fontSize = 12.sp, color = TextMuted)

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = LineBorder)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (order.paymentStatus != "Verified") {
                            Button(
                                onClick = {
                                    repository.updatePaymentStatus(order.id, "Verified")
                                    Toast.makeText(context, "Payment marked as VERIFIED", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("Verify Payment", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                        }

                        if (order.paymentStatus != "Rejected") {
                            OutlinedButton(
                                onClick = {
                                    repository.updatePaymentStatus(order.id, "Rejected")
                                    Toast.makeText(context, "Payment marked as REJECTED", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("Reject", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminRidersTab(
    orders: List<Order>,
    riderStatuses: Map<String, Boolean>,
    supportTickets: List<SupportTicket>,
    repository: BeerfoodRepository
) {
    val riders = listOf("Rider 1", "Ali Khan", "Usman", "Hamza")
    val unassignedOrders = orders.filter { it.rider.isBlank() && !listOf("Delivered", "Cancelled", "Unable to Deliver").contains(it.status) }
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Riders & Dispatch", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = InkDark)
            Text("Monitor active riders and dispatch unassigned orders.", fontSize = 12.sp, color = TextMuted)
        }

        // Active Riders
        item {
            Text("Registered Riders", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = InkDark)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                riders.forEach { name ->
                    val online = riderStatuses[name] ?: false
                    val activeCount = orders.count { it.rider == name && !listOf("Delivered", "Cancelled", "Unable to Deliver").contains(it.status) }
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("♙ $name", fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                            Text(if (online) "● Online" else "○ Offline", fontSize = 10.sp, color = if (online) ForestGreen else Color.Gray, fontWeight = FontWeight.Bold)
                            Text("$activeCount active", fontSize = 10.sp, color = TextMuted)
                        }
                    }
                }
            }
        }

        // Unassigned Orders Queue
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Unassigned Orders Queue (${unassignedOrders.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = InkDark)
                    Spacer(modifier = Modifier.height(6.dp))

                    if (unassignedOrders.isEmpty()) {
                        Text("All orders have riders assigned.", fontSize = 12.sp, color = TextMuted)
                    } else {
                        unassignedOrders.forEach { order ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(order.orderNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ForestGreen)
                                    Text("${order.customerName} · ${order.address.take(28)}...", fontSize = 11.sp, color = TextMuted)
                                    Text(formatPrice(order.total), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        repository.assignRider(order.id, "Rider 1")
                                        Toast.makeText(context, "Assigned ${order.orderNumber} to Rider 1", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("Assign Rider 1", fontSize = 11.sp)
                                }
                            }
                            HorizontalDivider(color = LineBorder.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }

        // Rider Support Tickets
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Rider Support Tickets (${supportTickets.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = InkDark)
                    Spacer(modifier = Modifier.height(6.dp))

                    if (supportTickets.isEmpty()) {
                        Text("No active tickets from riders.", fontSize = 12.sp, color = TextMuted)
                    } else {
                        supportTickets.forEach { ticket ->
                            Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${ticket.rider} · ${ticket.issue}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = InkDark)
                                    Text(ticket.status, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ForestGreen)
                                }
                                Text(ticket.message, fontSize = 12.sp, color = TextMuted)
                                if (ticket.status == "Open") {
                                    TextButton(
                                        onClick = {
                                            repository.updateSupportTicketStatus(ticket.id, "Resolved")
                                            Toast.makeText(context, "Ticket marked as RESOLVED", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Text("Mark Resolved", fontSize = 11.sp, color = ForestGreen)
                                    }
                                }
                            }
                            HorizontalDivider(color = LineBorder.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminReportsTab(orders: List<Order>) {
    var rangeFilter by remember { mutableStateOf("all") } // today, 7, 30, all

    val validOrders = orders.filter { it.status != "Cancelled" }
    val netSales = validOrders.sumOf { it.total }
    val deliveredCount = validOrders.count { it.status == "Delivered" }
    val avgOrder = if (validOrders.isNotEmpty()) netSales / validOrders.size else 0

    // Item sales
    val itemSales = mutableMapOf<String, Pair<Int, Int>>() // name -> (qty, sales)
    validOrders.forEach { o ->
        o.items.forEach { i ->
            val curr = itemSales[i.name] ?: (0 to 0)
            itemSales[i.name] = (curr.first + i.quantity) to (curr.second + (i.price * i.quantity))
        }
    }

    // Payment methods
    val paymentMethods = mutableMapOf<String, Pair<Int, Int>>() // method -> (count, sales)
    validOrders.forEach { o ->
        val curr = paymentMethods[o.payment] ?: (0 to 0)
        paymentMethods[o.payment] = (curr.first + 1) to (curr.second + o.total)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Reports & Performance", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = InkDark)
            Text("Track revenue, popular items and payment channels.", fontSize = 12.sp, color = TextMuted)
        }

        // Summary Grid
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AdminMetricCard(
                    title = "Net Sales",
                    value = formatPrice(netSales),
                    sub = "Excluding cancelled",
                    emoji = "💰",
                    modifier = Modifier.weight(1f)
                )
                AdminMetricCard(
                    title = "Orders",
                    value = "${orders.size}",
                    sub = "$deliveredCount delivered",
                    emoji = "🧾",
                    modifier = Modifier.weight(1f)
                )
                AdminMetricCard(
                    title = "Avg Order",
                    value = formatPrice(avgOrder),
                    sub = "Per order average",
                    emoji = "↗",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Top dishes breakdown
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Top Selling Items", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    Spacer(modifier = Modifier.height(8.dp))

                    if (itemSales.isEmpty()) {
                        Text("No sales data available.", fontSize = 12.sp, color = TextMuted)
                    } else {
                        itemSales.entries.sortedByDescending { it.value.first }.take(6).forEach { (name, stats) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(name, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = InkDark)
                                Row {
                                    Text("${stats.first} sold  ·  ", fontSize = 12.sp, color = TextMuted)
                                    Text(formatPrice(stats.second), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ForestGreen)
                                }
                            }
                            HorizontalDivider(color = LineBorder.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }

        // Payment method breakdown
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Payment Methods Breakdown", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkDark)
                    Spacer(modifier = Modifier.height(8.dp))

                    paymentMethods.forEach { (method, stats) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(method, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = InkDark)
                            Row {
                                Text("${stats.first} orders  ·  ", fontSize = 12.sp, color = TextMuted)
                                Text(formatPrice(stats.second), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ForestGreen)
                            }
                        }
                        HorizontalDivider(color = LineBorder.copy(alpha = 0.5f))
                    }
                }
            }
        }
    }
}

@Composable
fun AdminMetricCard(
    title: String,
    value: String,
    sub: String,
    emoji: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, LineBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Text(emoji, fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Black, color = InkDark, maxLines = 1)
            Text(sub, fontSize = 10.sp, color = TextMuted, maxLines = 1)
        }
    }
}
