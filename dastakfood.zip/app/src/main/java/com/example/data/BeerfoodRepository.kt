package com.example.data

import android.content.Context
import com.example.R
import com.example.model.CustomerUser
import com.example.model.Order
import com.example.model.OrderItem
import com.example.model.OrderLocation
import com.example.model.PaymentConfig
import com.example.model.Product
import com.example.model.Restaurant
import com.example.model.SupportTicket
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BeerfoodRepository private constructor() {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
    private var firestoreDb: FirebaseFirestore? = null
    private var ordersListener: ListenerRegistration? = null
    private var isFirestoreInitialized = false

    fun initFirestore(context: Context) {
        if (isFirestoreInitialized) return
        isFirestoreInitialized = true
        try {
            val dbId = context.getString(R.string.firestore_database_id)
            val db = FirebaseFirestore.getInstance(dbId)
            firestoreDb = db

            ordersListener = db.collection("orders")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) return@addSnapshotListener
                    if (snapshot != null && !snapshot.isEmpty) {
                        val remoteOrders = snapshot.documents.mapNotNull { doc ->
                            try {
                                val data = doc.data ?: return@mapNotNull null
                                val rawItems = data["items"] as? List<*> ?: emptyList<Any>()
                                val parsedItems = rawItems.mapNotNull { raw ->
                                    val m = raw as? Map<*, *> ?: return@mapNotNull null
                                    OrderItem(
                                        productId = m["productId"]?.toString() ?: "",
                                        name = m["name"]?.toString() ?: "",
                                        price = (m["price"] as? Number)?.toInt() ?: 0,
                                        quantity = (m["quantity"] as? Number)?.toInt() ?: 1,
                                        emoji = m["emoji"]?.toString() ?: "🍽️"
                                    )
                                }
                                Order(
                                    id = doc.id,
                                    orderNumber = data["orderNumber"]?.toString() ?: "BF-${doc.id.takeLast(6)}",
                                    customerName = data["customerName"]?.toString() ?: "Customer",
                                    phone = data["phone"]?.toString() ?: "",
                                    address = data["address"]?.toString() ?: "",
                                    location = OrderLocation(area = data["area"]?.toString() ?: ""),
                                    items = parsedItems,
                                    subtotal = (data["subtotal"] as? Number)?.toInt() ?: 0,
                                    deliveryFee = (data["deliveryFee"] as? Number)?.toInt() ?: 100,
                                    total = (data["total"] as? Number)?.toInt() ?: 0,
                                    payment = data["payment"]?.toString() ?: "Cash on Delivery",
                                    transactionReference = data["transactionReference"]?.toString() ?: "",
                                    paymentStatus = data["paymentStatus"]?.toString() ?: "Pay on delivery",
                                    status = data["status"]?.toString() ?: "New",
                                    rider = data["rider"]?.toString() ?: "",
                                    createdAt = data["createdAt"]?.toString() ?: "",
                                    updatedAt = data["updatedAt"]?.toString() ?: ""
                                )
                            } catch (e: Exception) {
                                null
                            }
                        }
                        if (remoteOrders.isNotEmpty()) {
                            val existingIds = remoteOrders.map { it.id }.toSet()
                            val localOnly = _orders.value.filter { it.id !in existingIds }
                            _orders.value = remoteOrders + localOnly
                        }
                    }
                }
        } catch (_: Exception) {}
    }

    private fun saveOrderToFirestore(order: Order) {
        try {
            val payload = mapOf(
                "id" to order.id,
                "orderNumber" to order.orderNumber,
                "customerName" to order.customerName,
                "phone" to order.phone,
                "address" to order.address,
                "area" to (order.location?.area ?: ""),
                "subtotal" to order.subtotal,
                "deliveryFee" to order.deliveryFee,
                "total" to order.total,
                "payment" to order.payment,
                "transactionReference" to order.transactionReference,
                "paymentStatus" to order.paymentStatus,
                "status" to order.status,
                "rider" to order.rider,
                "createdAt" to order.createdAt,
                "updatedAt" to order.updatedAt,
                "items" to order.items.map {
                    mapOf(
                        "productId" to it.productId,
                        "name" to it.name,
                        "price" to it.price,
                        "quantity" to it.quantity,
                        "emoji" to it.emoji
                    )
                }
            )
            firestoreDb?.collection("orders")?.document(order.id)?.set(payload)
        } catch (_: Exception) {}
    }

    private fun updateOrderInFirestore(orderId: String, updates: Map<String, Any>) {
        try {
            firestoreDb?.collection("orders")?.document(orderId)?.update(updates)
        } catch (_: Exception) {}
    }

    private val initialCategories = listOf(
        "Burgers", "Biryani", "Pizza", "Pakistani", "Desserts", "Drinks", "Groceries", "Vegetables", "Home Items"
    )

    private val initialProducts = listOf(
        Product(
            id = "p1",
            name = "Classic Burger",
            category = "Burgers",
            price = 450,
            emoji = "🍔",
            description = "Grilled juicy patty, crisp iceberg, melted cheese & house secret sauce"
        ),
        Product(
            id = "p2",
            name = "Chicken Biryani",
            category = "Biryani",
            price = 520,
            emoji = "🍛",
            description = "Fragrant basmati rice layered with spiced marinated chicken and potatoes"
        ),
        Product(
            id = "p3",
            name = "Cheese Pizza",
            category = "Pizza",
            price = 850,
            emoji = "🍕",
            description = "Stone-baked thin crust loaded with rich mozzarella, herbs and pizza sauce"
        ),
        Product(
            id = "p4",
            name = "Chicken Karahi",
            category = "Pakistani",
            price = 1200,
            emoji = "🥘",
            description = "Traditional clay-pot cooked chicken karahi with fresh ginger, serves two"
        ),
        Product(
            id = "p5",
            name = "Chocolate Cake",
            category = "Desserts",
            price = 350,
            emoji = "🍰",
            description = "Decadent rich dark chocolate slice with ganache glaze"
        ),
        Product(
            id = "p6",
            name = "Fresh Lemonade",
            category = "Drinks",
            price = 180,
            emoji = "🍋",
            description = "Freshly squeezed lemon with mint and crushed ice"
        ),
        Product(
            id = "p7",
            name = "Fresh Tomatoes (1 kg)",
            category = "Groceries",
            price = 160,
            emoji = "🍅",
            description = "Farm-fresh ripe red tomatoes directly from local markets"
        ),
        Product(
            id = "p8",
            name = "Fresh Milk (1 litre)",
            category = "Groceries",
            price = 230,
            emoji = "🥛",
            description = "Fresh wholesome dairy milk packed chilled"
        ),
        Product(
            id = "p9",
            name = "Farm Eggs (dozen)",
            category = "Groceries",
            price = 360,
            emoji = "🥚",
            description = "A dozen fresh farm eggs"
        ),
        Product(
            id = "p10",
            name = "Potatoes (1 kg)",
            category = "Vegetables",
            price = 110,
            emoji = "🥔",
            description = "Fresh local organic potatoes"
        ),
        Product(
            id = "p11",
            name = "Spinach Bunch",
            category = "Vegetables",
            price = 90,
            emoji = "🥬",
            description = "Tender green spinach bunch harvested this morning"
        ),
        Product(
            id = "p12",
            name = "Dish Soap",
            category = "Home Items",
            price = 240,
            emoji = "🧼",
            description = "Tough on grease, gentle on hands household dish wash"
        ),
        Product(
            id = "p13",
            name = "Laundry Detergent",
            category = "Home Items",
            price = 520,
            emoji = "🧺",
            description = "Household laundry pack with brightening formula"
        )
    )

    val restaurants = listOf(
        Restaurant(
            id = "karahi",
            name = "Karahi House",
            category = "Pakistani",
            kind = "restaurant",
            pickup = true,
            emoji = "🥘",
            rating = 4.8,
            reviews = "1.2k+",
            mins = 25,
            distance = "1.4 km",
            offer = "20% off"
        ),
        Restaurant(
            id = "crust",
            name = "Crust & Co.",
            category = "Pizza",
            kind = "restaurant",
            pickup = true,
            emoji = "🍕",
            rating = 4.7,
            reviews = "840+",
            mins = 30,
            distance = "2.1 km",
            offer = "Free delivery"
        ),
        Restaurant(
            id = "street",
            name = "Street Bite Kitchen",
            category = "Burgers",
            kind = "restaurant",
            pickup = true,
            emoji = "🍔",
            rating = 4.6,
            reviews = "690+",
            mins = 20,
            distance = "900 m",
            offer = "15% off"
        ),
        Restaurant(
            id = "biryani",
            name = "Biryani Junction",
            category = "Biryani",
            kind = "restaurant",
            pickup = true,
            emoji = "🍚",
            rating = 4.9,
            reviews = "2k+",
            mins = 28,
            distance = "1.8 km",
            offer = "Popular"
        ),
        Restaurant(
            id = "sweet",
            name = "Sweet Corner",
            category = "Desserts",
            kind = "restaurant",
            pickup = true,
            emoji = "🍰",
            rating = 4.5,
            reviews = "510+",
            mins = 22,
            distance = "1.1 km",
            offer = "10% off"
        ),
        Restaurant(
            id = "chai",
            name = "Chai & Chill",
            category = "Drinks",
            kind = "restaurant",
            pickup = true,
            emoji = "🧋",
            rating = 4.7,
            reviews = "420+",
            mins = 18,
            distance = "700 m",
            offer = "Combo deal"
        ),
        Restaurant(
            id = "basket",
            name = "Daily Basket",
            category = "Groceries",
            kind = "grocery",
            pickup = true,
            emoji = "🛒",
            rating = 4.6,
            reviews = "260+",
            mins = 25,
            distance = "1.3 km",
            offer = "Grocery deals"
        ),
        Restaurant(
            id = "green",
            name = "Green Grocer",
            category = "Vegetables",
            kind = "grocery",
            pickup = true,
            emoji = "🥬",
            rating = 4.7,
            reviews = "310+",
            mins = 20,
            distance = "800 m",
            offer = "Fresh today"
        ),
        Restaurant(
            id = "home",
            name = "Home Essentials",
            category = "Home Items",
            kind = "shop",
            pickup = true,
            emoji = "🧺",
            rating = 4.5,
            reviews = "190+",
            mins = 25,
            distance = "1.6 km",
            offer = "Home deals"
        ),
        Restaurant(
            id = "corner",
            name = "Mohalla General Store",
            category = "Groceries",
            kind = "shop",
            pickup = true,
            emoji = "🏪",
            rating = 4.6,
            reviews = "230+",
            mins = 18,
            distance = "600 m",
            offer = "Local favorite"
        )
    )

    private val initialOrders = listOf(
        Order(
            id = "df0ff240-3a0a-4742-956d-1c5fcbfe8f45",
            orderNumber = "BF-0379458",
            customerName = "Adil",
            phone = "03000854388",
            address = "Street 24 House No 67, Mohra Sharif, Lahore",
            location = OrderLocation(area = "Mohra Sharif, Lahore"),
            items = listOf(
                OrderItem(productId = "p2", name = "Chicken Biryani", price = 520, quantity = 1, emoji = "🍛")
            ),
            subtotal = 520,
            deliveryFee = 100,
            total = 620,
            payment = "Cash on Delivery",
            paymentStatus = "Pay on delivery",
            status = "New",
            rider = "",
            createdAt = "2026-10-25T11:12:59.466Z"
        ),
        Order(
            id = "57ffb9a9-3cd8-474b-8d42-76e17db584a0",
            orderNumber = "BF-1363770",
            customerName = "Saqib",
            phone = "03094489584",
            address = "House 67 Street 24, 60 Feet Road, Lahore",
            location = OrderLocation(area = "Gulberg III, Lahore"),
            items = listOf(
                OrderItem(productId = "p2", name = "Chicken Biryani", price = 520, quantity = 1, emoji = "🍛"),
                OrderItem(productId = "p6", name = "Fresh Lemonade", price = 180, quantity = 2, emoji = "🍋")
            ),
            subtotal = 880,
            deliveryFee = 100,
            total = 980,
            payment = "Easypaisa",
            transactionReference = "EP-983142750",
            paymentStatus = "Pending manual verification",
            status = "Confirmed",
            rider = "Rider 1",
            createdAt = "2026-10-25T08:42:43.774Z"
        ),
        Order(
            id = "2bb0bfcc-7104-4127-8dc6-13344f7b9704",
            orderNumber = "BF-0710295",
            customerName = "Saqib",
            phone = "03094489584",
            address = "Sector Y DHA Phase 3, Lahore",
            location = OrderLocation(area = "DHA Phase 3"),
            items = listOf(
                OrderItem(productId = "p1", name = "Classic Burger", price = 450, quantity = 2, emoji = "🍔")
            ),
            subtotal = 900,
            deliveryFee = 100,
            total = 1000,
            payment = "Cash on Delivery",
            paymentStatus = "Pay on delivery",
            status = "On the Way",
            rider = "Rider 1",
            createdAt = "2026-10-25T08:31:50.300Z",
            updatedAt = "2026-10-25T08:33:37.303Z"
        )
    )

    private val initialTickets = listOf(
        SupportTicket(
            id = "b5c6ee91-7123-4b69-b6f9-ccd5c247ef29",
            rider = "Rider 1",
            orderId = "2bb0bfcc-7104-4127-8dc6-13344f7b9704",
            orderNumber = "BF-0710295",
            issue = "Payment or collection",
            message = "Customer requested exact change for Rs 2000 note.",
            status = "Open",
            createdAt = "2026-10-25T12:15:19.364Z"
        )
    )

    private val _categories = MutableStateFlow(initialCategories)
    val categories: StateFlow<List<String>> = _categories.asStateFlow()

    private val _products = MutableStateFlow(initialProducts)
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _orders = MutableStateFlow(initialOrders)
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _riderStatuses = MutableStateFlow(
        mutableMapOf("Rider 1" to true, "Ali Khan" to false)
    )
    val riderStatuses: StateFlow<Map<String, Boolean>> = _riderStatuses.asStateFlow()

    private val _supportTickets = MutableStateFlow(initialTickets)
    val supportTickets: StateFlow<List<SupportTicket>> = _supportTickets.asStateFlow()

    private val _currentUser = MutableStateFlow<CustomerUser?>(
        CustomerUser(id = "user-1", name = "Saqib Bhatti", phone = "03094489584", createdAt = "2026-10-24")
    )
    val currentUser: StateFlow<CustomerUser?> = _currentUser.asStateFlow()

    private val _selectedArea = MutableStateFlow("Mohra Sharif, Lahore")
    val selectedArea: StateFlow<String> = _selectedArea.asStateFlow()

    private val _paymentConfig = MutableStateFlow(PaymentConfig())
    val paymentConfig: StateFlow<PaymentConfig> = _paymentConfig.asStateFlow()

    fun setArea(area: String) {
        _selectedArea.value = area
    }

    // ── Cart & Orders ──────────────────────────────────────────────
    fun placeOrder(
        customerName: String,
        phone: String,
        address: String,
        cartItems: Map<String, Int>,
        paymentMethod: String,
        transactionReference: String,
        area: String
    ): Result<Order> {
        if (customerName.isBlank() || phone.isBlank() || address.isBlank() || cartItems.isEmpty()) {
            return Result.failure(IllegalArgumentException("Name, phone, address and at least one item are required."))
        }

        val allProducts = _products.value.associateBy { it.id }
        val orderItems = cartItems.mapNotNull { (productId, qty) ->
            val p = allProducts[productId] ?: return@mapNotNull null
            if (!p.available) return@mapNotNull null
            OrderItem(
                productId = p.id,
                name = p.name,
                price = p.price,
                quantity = qty.coerceAtLeast(1),
                emoji = p.emoji
            )
        }

        if (orderItems.isEmpty()) {
            return Result.failure(IllegalStateException("Selected items are no longer available."))
        }

        val subtotal = orderItems.sumOf { it.price * it.quantity }
        val deliveryFee = 100
        val total = subtotal + deliveryFee
        val now = dateFormat.format(Date())
        val orderNum = "BF-" + (System.currentTimeMillis().toString().takeLast(7))

        val order = Order(
            id = UUID.randomUUID().toString(),
            orderNumber = orderNum,
            customerName = customerName.trim(),
            phone = phone.trim(),
            address = address.trim(),
            location = OrderLocation(area = area),
            items = orderItems,
            subtotal = subtotal,
            deliveryFee = deliveryFee,
            total = total,
            payment = paymentMethod,
            transactionReference = if (paymentMethod == "Cash on Delivery") "" else transactionReference.trim(),
            paymentStatus = if (paymentMethod == "Cash on Delivery") "Pay on delivery" else "Pending manual verification",
            status = "New",
            rider = "",
            createdAt = now
        )

        _orders.value = listOf(order) + _orders.value
        saveOrderToFirestore(order)
        return Result.success(order)
    }

    fun updateOrderStatus(orderId: String, newStatus: String) {
        val now = dateFormat.format(Date())
        _orders.value = _orders.value.map { order ->
            if (order.id == orderId) {
                order.copy(status = newStatus, updatedAt = now)
            } else {
                order
            }
        }
        updateOrderInFirestore(orderId, mapOf("status" to newStatus, "updatedAt" to now))
    }

    fun assignRider(orderId: String, riderName: String) {
        val now = dateFormat.format(Date())
        var assignedStatus = ""
        _orders.value = _orders.value.map { order ->
            if (order.id == orderId) {
                val newStatus = if (riderName.isNotBlank() && order.status == "New") "Confirmed" else order.status
                assignedStatus = newStatus
                order.copy(rider = riderName.trim(), status = newStatus, updatedAt = now)
            } else {
                order
            }
        }
        val updates = mutableMapOf<String, Any>("rider" to riderName.trim(), "updatedAt" to now)
        if (assignedStatus.isNotBlank()) updates["status"] = assignedStatus
        updateOrderInFirestore(orderId, updates)
    }

    fun acceptDelivery(orderId: String, riderName: String) {
        val now = dateFormat.format(Date())
        _orders.value = _orders.value.map { order ->
            if (order.id == orderId) {
                order.copy(rider = riderName.trim(), status = "Confirmed", updatedAt = now)
            } else {
                order
            }
        }
        updateOrderInFirestore(orderId, mapOf("rider" to riderName.trim(), "status" to "Confirmed", "updatedAt" to now))
    }

    fun declineDelivery(orderId: String, riderName: String) {
        val now = dateFormat.format(Date())
        _orders.value = _orders.value.map { order ->
            if (order.id == orderId && order.rider.equals(riderName, ignoreCase = true)) {
                order.copy(rider = "", updatedAt = now)
            } else {
                order
            }
        }
        updateOrderInFirestore(orderId, mapOf("rider" to "", "updatedAt" to now))
    }

    fun updateOrderLocation(orderId: String, locationArea: String) {
        val now = dateFormat.format(Date())
        _orders.value = _orders.value.map { order ->
            if (order.id == orderId) {
                order.copy(
                    location = OrderLocation(area = locationArea),
                    updatedAt = now
                )
            } else {
                order
            }
        }
        updateOrderInFirestore(orderId, mapOf("area" to locationArea, "updatedAt" to now))
    }

    fun updatePaymentStatus(orderId: String, paymentStatus: String) {
        val now = dateFormat.format(Date())
        _orders.value = _orders.value.map { order ->
            if (order.id == orderId) {
                order.copy(paymentStatus = paymentStatus, updatedAt = now)
            } else {
                order
            }
        }
        updateOrderInFirestore(orderId, mapOf("paymentStatus" to paymentStatus, "updatedAt" to now))
    }

    // ── Catalog Management ──────────────────────────────────────────
    fun addCategory(categoryName: String): Boolean {
        val name = categoryName.trim()
        if (name.isBlank()) return false
        if (!_categories.value.any { it.equals(name, ignoreCase = true) }) {
            _categories.value = _categories.value + name
            return true
        }
        return false
    }

    fun addProduct(
        name: String,
        category: String,
        price: Int,
        emoji: String,
        description: String
    ): Boolean {
        if (name.isBlank() || price <= 0 || !_categories.value.contains(category)) return false
        val newProduct = Product(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            category = category,
            price = price,
            emoji = emoji.ifBlank { "🍽️" },
            description = description.trim(),
            available = true
        )
        _products.value = listOf(newProduct) + _products.value
        return true
    }

    fun toggleProductAvailability(productId: String) {
        _products.value = _products.value.map { p ->
            if (p.id == productId) p.copy(available = !p.available) else p
        }
    }

    fun deleteProduct(productId: String) {
        _products.value = _products.value.filterNot { it.id == productId }
    }

    // ── Rider Controls ──────────────────────────────────────────────
    fun toggleRiderOnline(riderName: String, online: Boolean) {
        val current = _riderStatuses.value.toMutableMap()
        current[riderName] = online
        _riderStatuses.value = current
    }

    fun fileSupportTicket(rider: String, orderId: String, orderNumber: String, issue: String, message: String): Boolean {
        if (rider.isBlank() || message.isBlank()) return false
        val ticket = SupportTicket(
            id = UUID.randomUUID().toString(),
            rider = rider.trim(),
            orderId = orderId,
            orderNumber = orderNumber,
            issue = issue,
            message = message.trim(),
            status = "Open",
            createdAt = dateFormat.format(Date())
        )
        _supportTickets.value = listOf(ticket) + _supportTickets.value
        return true
    }

    fun updateSupportTicketStatus(ticketId: String, status: String) {
        _supportTickets.value = _supportTickets.value.map { ticket ->
            if (ticket.id == ticketId) ticket.copy(status = status) else ticket
        }
    }

    // ── Auth & Users ────────────────────────────────────────────────
    fun checkUserRoleInFirestore(uid: String, fallbackRole: String = "customer", onResult: (String) -> Unit) {
        val db = firestoreDb
        if (db == null) {
            onResult(fallbackRole)
            return
        }
        db.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                val firestoreRole = doc?.getString("role")
                if (!firestoreRole.isNullOrBlank()) {
                    onResult(firestoreRole)
                } else {
                    onResult(fallbackRole)
                }
            }
            .addOnFailureListener {
                onResult(fallbackRole)
            }
    }

    fun signInWithGoogle(
        idToken: String,
        role: String,
        onRoleResolved: ((String, CustomerUser) -> Unit)? = null,
        onError: ((Exception) -> Unit)? = null
    ) {
        try {
            val auth = FirebaseAuth.getInstance()
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            auth.signInWithCredential(credential).addOnSuccessListener { authResult ->
                val firebaseUser = authResult.user
                val name = firebaseUser?.displayName ?: "Google User"
                val email = firebaseUser?.email ?: ""
                val phone = firebaseUser?.phoneNumber ?: ""
                val uid = firebaseUser?.uid ?: UUID.randomUUID().toString()

                val docRef = firestoreDb?.collection("users")?.document(uid)
                if (docRef != null) {
                    docRef.get().addOnSuccessListener { doc ->
                        val existingRole = doc?.getString("role")
                        val effectiveRole = if (!existingRole.isNullOrBlank()) existingRole else role
                        val user = CustomerUser(
                            id = uid,
                            name = doc?.getString("name") ?: name,
                            phone = doc?.getString("phone") ?: (if (phone.isNotBlank()) phone else "+92 300 0000000"),
                            email = doc?.getString("email") ?: email,
                            role = effectiveRole,
                            createdAt = doc?.getString("createdAt") ?: dateFormat.format(Date())
                        )
                        _currentUser.value = user
                        docRef.set(
                            mapOf(
                                "id" to uid,
                                "name" to user.name,
                                "email" to user.email,
                                "phone" to user.phone,
                                "role" to effectiveRole,
                                "createdAt" to user.createdAt
                            )
                        )
                        onRoleResolved?.invoke(effectiveRole, user)
                    }.addOnFailureListener {
                        val user = CustomerUser(
                            id = uid,
                            name = name,
                            phone = if (phone.isNotBlank()) phone else "+92 300 0000000",
                            email = email,
                            role = role,
                            createdAt = dateFormat.format(Date())
                        )
                        _currentUser.value = user
                        docRef.set(
                            mapOf(
                                "id" to uid,
                                "name" to name,
                                "email" to email,
                                "phone" to user.phone,
                                "role" to role,
                                "createdAt" to user.createdAt
                            )
                        )
                        onRoleResolved?.invoke(role, user)
                    }
                } else {
                    val user = CustomerUser(
                        id = uid,
                        name = name,
                        phone = if (phone.isNotBlank()) phone else "+92 300 0000000",
                        email = email,
                        role = role,
                        createdAt = dateFormat.format(Date())
                    )
                    _currentUser.value = user
                    onRoleResolved?.invoke(role, user)
                }
            }.addOnFailureListener { e ->
                onError?.invoke(e)
            }
        } catch (e: Exception) {
            onError?.invoke(e)
        }
    }

    fun verifyPhoneOtp(
        phone: String,
        code: String,
        name: String?,
        role: String = "customer",
        onRoleResolved: ((String, CustomerUser) -> Unit)? = null
    ): Result<CustomerUser> {
        val cleanPhone = phone.replace(Regex("[^0-9+]"), "")
        if (cleanPhone.length < 10) {
            return Result.failure(IllegalArgumentException("Enter a valid phone number."))
        }
        // Accept test phone +1 202-555-0147 with code 583104 or any 6-digit test OTP
        if (code.trim().length != 6 && code.trim() != "583104") {
            return Result.failure(IllegalArgumentException("Enter the 6-digit SMS verification code."))
        }

        val displayName = if (!name.isNullOrBlank()) name.trim() else "${role.replaceFirstChar { it.uppercase() }} ${cleanPhone.takeLast(4)}"
        val uid = "user_${cleanPhone.filter { it.isDigit() }}"
        val user = CustomerUser(
            id = uid,
            name = displayName,
            phone = cleanPhone,
            role = role,
            createdAt = dateFormat.format(Date())
        )
        _currentUser.value = user
        try {
            val docRef = firestoreDb?.collection("users")?.document(uid)
            if (docRef != null) {
                docRef.get().addOnSuccessListener { doc ->
                    val existingRole = doc?.getString("role")
                    val effectiveRole = if (!existingRole.isNullOrBlank()) existingRole else role
                    val finalUser = user.copy(role = effectiveRole)
                    _currentUser.value = finalUser
                    docRef.set(
                        mapOf(
                            "id" to uid,
                            "name" to displayName,
                            "phone" to cleanPhone,
                            "role" to effectiveRole,
                            "createdAt" to user.createdAt
                        )
                    )
                    onRoleResolved?.invoke(effectiveRole, finalUser)
                }.addOnFailureListener {
                    docRef.set(
                        mapOf(
                            "id" to uid,
                            "name" to displayName,
                            "phone" to cleanPhone,
                            "role" to role,
                            "createdAt" to user.createdAt
                        )
                    )
                    onRoleResolved?.invoke(role, user)
                }
            } else {
                onRoleResolved?.invoke(role, user)
            }
        } catch (_: Exception) {
            onRoleResolved?.invoke(role, user)
        }
        return Result.success(user)
    }

    fun loginDemoUser(
        name: String,
        phone: String,
        role: String,
        onRoleResolved: ((String, CustomerUser) -> Unit)? = null
    ) {
        val uid = "demo-$role"
        val user = CustomerUser(
            id = uid,
            name = name,
            phone = phone,
            role = role,
            createdAt = dateFormat.format(Date())
        )
        _currentUser.value = user
        try {
            firestoreDb?.collection("users")?.document(uid)?.set(
                mapOf(
                    "id" to uid,
                    "name" to name,
                    "phone" to phone,
                    "role" to role,
                    "createdAt" to user.createdAt
                )
            )
        } catch (_: Exception) {}
        onRoleResolved?.invoke(role, user)
    }

    fun verifyOtp(phone: String, code: String, name: String?): Result<CustomerUser> {
        return verifyPhoneOtp(phone, code, name, "customer")
    }

    fun logout() {
        try {
            FirebaseAuth.getInstance().signOut()
        } catch (_: Exception) {}
        _currentUser.value = null
    }

    companion object {
        @Volatile
        private var INSTANCE: BeerfoodRepository? = null

        fun getInstance(): BeerfoodRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: BeerfoodRepository().also { INSTANCE = it }
            }
        }
    }
}
