# Beerfood (Dastakfood) - Android Application

Beerfood is a modern food, grocery, and household essentials ordering platform built natively for Android using Kotlin and Jetpack Compose with Material Design 3.

## Features

### 1. Customer Ordering Portal
- **Location & Delivering-To Area Selection**: Quick selection for Lahore areas (Mohra Sharif, Gulberg, DHA, Model Town, Johar Town, etc.) with custom manual address entry.
- **Service Modes**: Seamlessly browse between Delivery, Pickup, Groceries, and Neighborhood Shops.
- **Cuisine & Craving Discovery**: Interactive chips with emojis for Burgers, Biryani, Pizza, Pakistani Dishes, Desserts, Drinks, Groceries, and Fresh Produce.
- **Curated Deals & Discounts**: Promotional banners for first orders, lunch specials, and kitchen essentials.
- **Search & Filters**: Real-time search across kitchens and items with sort options (Recommended, Top Rated, Fastest Delivery, and Has Offers).
- **Restaurant & Menu Browsing**: View store details, rating, reviews, delivery estimates, item descriptions, and prices in Pakistani Rupees (PKR).
- **Interactive Cart & Checkout**:
  - Quantity controls, instant subtotal, delivery fee calculation (Rs. 100), and total price.
  - Delivery details: Customer name, phone, address.
  - Payment methods: Cash on Delivery, Easypaisa, JazzCash, and Bank Transfer with transaction reference submission.
- **Customer Account & OTP Verification**: Phone sign-in flow with simulated local testing OTP support (`+1 202-555-0147` / code `583104`).
- **Order History & Tracking**: Real-time order status tracking with order number (e.g. `BF-xxxxxxx`).

### 2. Rider Delivery Portal
- **Rider Identity & Selection**: Switch between registered riders (Rider 1, Ali Khan, Usman, etc.).
- **Online / Offline Availability**: Real-time toggle controlling rider delivery status.
- **Delivery Workflow Stages**:
  - New / Confirmed orders -> Mark Picked Up
  - Picked Up -> Start Delivery (On the Way)
  - On the Way -> Mark Delivered, or report issue
- **Customer Communication & Navigation**:
  - One-tap customer dial intent (`tel:`)
  - One-tap Google Maps directions intent
  - One-tap delivery address clipboard copy
- **Cash on Delivery Collection & Payment Badge**: Explicit instructions on cash amount to collect or prepaid verification state.
- **Rider Support Tickets**: Submit issue tickets directly to store admin.

### 3. Store Admin Console
- **Overview Dashboard**: Today's sales (Rs), order volume, attention needed counter, catalog size, and recent orders.
- **Orders Dispatch & Status Management**: Search, filter by status, change status dropdown, and assign orders to riders.
- **Menu & Catalog Management**:
  - Category tabs
  - Add new menu items (name, price, category, emoji icon, description)
  - Add new categories
  - Toggle item stock availability (Available vs Sold Out)
  - Delete items
- **Payment Verification**: Review Easypaisa, JazzCash, and Bank Transfer payments, confirm transaction references, and mark as Verified or Rejected.
- **Rider Dispatch Queue**: Overview of active delivery riders and unassigned orders queue with one-click dispatch.
- **Reports & Performance Analytics**: Sales metrics, average order value, top-selling items by volume, and payment method breakdown.

## Tech Stack
- **Language**: Kotlin 2.2
- **UI Framework**: Jetpack Compose (Material 3)
- **Architecture**: MVVM with unidirectional data flow and Kotlin Coroutines / StateFlow
- **Minimum SDK**: 26 (Android 8.0)
- **Target SDK**: 36 (Android 16)
